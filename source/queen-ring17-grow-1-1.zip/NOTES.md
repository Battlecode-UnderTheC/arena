# queen-ring17-grow-1

Parent: queen-ring17-hunt-3-1. Replay analysis: our alive dragon count at round 100 is about 33 in wins
versus 17.5 in losses, and splitting already starts at the legal floor (length 4). So this variant keeps
the nearest-pearl opening rule and lower trap cost for longer (kGreedyUntil 150 -> 250), to test whether
faster early pearl gathering lifts the round-100 swarm and the win rate.
