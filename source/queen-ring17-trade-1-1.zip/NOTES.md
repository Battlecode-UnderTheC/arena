# queen-ring17-trade-1

Parent: queen-ring17-hunt-3-1. Replay analysis (ring-plus-9 games): in our losses we traded head-to-head
about twice as often per dragon-round in the first 100 rounds (0.90 vs 0.46 per 100 dragon-rounds).
Change: before round 100, a worker only trades with an enemy head at least 2 segments longer
(kTradeEarlyMargin). Tests whether early one-for-one attrition is what loses games.
