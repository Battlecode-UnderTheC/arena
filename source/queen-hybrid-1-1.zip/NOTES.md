# queen-hybrid-1

Parent: `queen-trade-1` (the outnumbered-gate fix, drafted at `queen-trade-1-1`, net-neutral vs
`queen-3` on the full arena suite). Adds a proactive queen-hunt on top of it.

## The idea

`queen-3`/`queen-trade-1` only trade with the enemy queen opportunistically, if a worker happens
to end up adjacent to its last known position -- nothing paths toward it deliberately. Since
dragon ids 0/1 are always the two queens, a worker always knows the enemy queen's id (1 minus its
own queen's id) even before ever sighting it, so pathing there once it has a trackable sighting is
cheap to add: a spare worker (length >= `kHuntMinLength`, not needed for feeding) with a sighting
of the enemy queen no older than `kHuntStale` rounds treats its last-known tile as a goal instead
of the nearest pearl. Gated by the same outnumbered check `WorthTrading`'s queen-kill case uses,
re-evaluated every turn, so a chase aborts mid-way if we start losing the attrition war.

## Why this is being retested

The first pass (local-only) tested this against `queen-2-base`/`queen-3-base`/`gst-giant-2-base`
copies sitting in this checkout and found no effect either way: the enemy queen already died in
90-100% of games with zero hunting, leaving no headroom for deliberate pursuit to add anything.
But those local copies turned out to be a poor proxy for the current meta -- a separate
investigation (tuning `queen-guard-7`'s weights) found it losing *consistently* to those exact
same local copies despite being the #1 rated bot in the arena by a wide margin, which only makes
sense if `queen-2-base`/`queen-3-base` are unusually old/weak relative to where the arena's actual
population has moved (queen-guard, crossover, queen-ring6, codex-queen-value lines didn't exist
when this project started). So the original "hunting doesn't help" conclusion was drawn against
opponents that may not represent anything a real submission will actually face. Submitting this
draft is the only way to test it against the arena's real current population instead.

## What to watch for in the verdict

- Overall win rate vs parent (`queen-trade-1-1`) and vs the draft lane's actual opponent set.
- Whether games are now ending via the "longer queen" criterion more than they were for the
  parent -- that's the direct signal the hunt mechanism is doing something, as opposed to a
  win-rate move that could come from somewhere else entirely.
