#include "team_memory.hpp"

#include <algorithm>

namespace ex2 {

TeamMemory::TeamMemory(int32_t width, int32_t height)
    : w_(width), h_(height), tiles_(width * height), north_(width * height, kEdgeUnseen),
      west_(width * height, kEdgeUnseen) {}

int32_t TeamMemory::Tile(int32_t x, int32_t y) const {
  x = ((x % w_) + w_) % w_;
  y = ((y % h_) + h_) % h_;
  return y * w_ + x;
}

void TeamMemory::Update(const rl::Observation& o) {
  round_ = o.round;
  constexpr int R = dragons::kVisionRadius, V = dragons::kVision;
  const int32_t hx = o.head_x(), hy = o.head_y();
  // tiles: seen now, pearls and beds as they are, occupants cleared (bodies are added below)
  for (int k = 0; k < rl::kWindowTiles; ++k) {
    TileMemory& m = tiles_[Tile(o.tile_x[k], o.tile_y[k])];
    m.seen_round = round_;
    m.pearl = o.pearl[k] != 0;
    m.countdown = o.countdown[k];
    m.occupant = -1;
  }
  for (const rl::Segment& s : o.segments) {
    TileMemory& m = tiles_[Tile(s.x, s.y)];
    m.occupant = s.id;
    m.occupant_team = s.team;
    m.occupant_head = s.head;
  }
  // edges: north sides of window rows 0..7, west sides of window columns 0..7
  for (int r = 0; r <= V; ++r)
    for (int c = 0; c < V; ++c) Note(true, hx - R + c, hy - R + r, o.hedge[r * V + c]);
  for (int r = 0; r < V; ++r)
    for (int c = 0; c <= V; ++c) Note(false, hx - R + c, hy - R + r, o.vedge[r * (V + 1) + c]);
}

void TeamMemory::Note(bool horizontal, int32_t x, int32_t y, int32_t code) {
  const int32_t t = Tile(x, y);
  (horizontal ? north_ : west_)[t] = code;
  if (code >= 0) {                                   // a portal end
    const EdgeRef e{horizontal, X(t), Y(t)};
    auto& ends = portal_ends_[code];
    if (std::find(ends.begin(), ends.end(), e) == ends.end()) ends.push_back(e);
  }
}

void TeamMemory::Merge(int32_t x, int32_t y, int32_t north, int32_t west, int32_t next_pearl, bool pearl, int32_t seen) {
  if (x < 0 || x >= w_ || y < 0 || y >= h_ || seen > round_) return;
  const int32_t t = Tile(x, y);
  if (north_[t] == kEdgeUnseen) Note(true, x, y, north);
  if (west_[t] == kEdgeUnseen) Note(false, x, y, west);
  TileMemory& m = tiles_[t];
  if (seen <= m.seen_round) return;
  m.seen_round = seen;
  m.pearl = pearl;
  m.countdown = next_pearl < 0 ? -1 : next_pearl - seen;
  m.occupant = -1;
}

int32_t TeamMemory::SideCode(int32_t t, int dir) const {
  const int32_t x = X(t), y = Y(t);
  switch (dir) {
    case 0: return north_[t];
    case 2: return north_[Tile(x, y + 1)];
    case 3: return west_[t];
    default: return west_[Tile(x + 1, y)];
  }
}

// engine: TileAfterCrossing -- out of the partner edge, still heading the same way
int32_t TeamMemory::Exit(const EdgeRef& e, int dir) const {
  if (e.horizontal) return Tile(e.x, dir == 2 ? e.y : e.y - 1);
  return Tile(dir == 1 ? e.x : e.x - 1, e.y);
}

int32_t TeamMemory::Step(int32_t t, int dir) const {
  const int32_t code = SideCode(t, dir);
  if (code == kEdgeUnseen) return kUnknown;
  if (code == dragons::kEdgeKelp) return kBlocked;
  if (code == dragons::kEdgeEmpty) return Tile(X(t) + dragons::kDx[dir], Y(t) + dragons::kDy[dir]);
  // a portal: this side's edge, then the other end with the same id
  const int32_t x = X(t), y = Y(t);
  const EdgeRef here = dir == 0   ? EdgeRef{true, x, y}
                       : dir == 2 ? EdgeRef{true, X(Tile(x, y + 1)), Y(Tile(x, y + 1))}
                       : dir == 3 ? EdgeRef{false, x, y}
                                  : EdgeRef{false, X(Tile(x + 1, y)), Y(Tile(x + 1, y))};
  const auto it = portal_ends_.find(code);
  if (it == portal_ends_.end()) return kUnknown;
  for (const EdgeRef& e : it->second)
    if (!(e == here)) return Exit(e, dir);
  return kUnknown;
}

}  // namespace ex2
