// explorer-2's sonar words, at most 56 bits (what a word may carry). From the low bit:
//   tile:  tag 4 | type 2 (1) | x 8 | y 8 | north edge 6 | west edge 6 | bed 1 |
//          next pearl round 9 | pearl 1 | seen round 9                             (54 bits)
//   queen: tag 4 | type 2 (2) | x 8 | y 8 | round 9 | home x 8 | home y 8 | distress 1   (48 bits)
//          where our queen's head was (and when), and her home: the centre of the territory
//          no worker enters
// Edge codes: 0 empty, 1 kelp, 2 + portal id (ids up to 61). The tag is a checksum of the
// rest with a salt, so words that aren't ours (an enemy's, or noise) are dropped.
#pragma once

#include <cstdint>

namespace sonar {

inline constexpr int kWordBits = 56;
inline constexpr uint64_t kSalt = 0x9e3779b97f4a7c15ull;
inline constexpr uint64_t kTypeTile = 1;
inline constexpr uint64_t kTypeQueen = 2;

struct TileMsg {
  int32_t x = 0, y = 0;
  int32_t north = -1, west = -1;   // edge codes as the board has them: -1 empty, -2 kelp, a portal id
  int32_t next_pearl = -1;         // the bed's next pearl round, -1 no bed
  bool pearl = false;
  int32_t seen = 0;                // the round this was seen
};

inline uint64_t Tag(uint64_t payload) {
  uint64_t h = (payload ^ kSalt) * 0xbf58476d1ce4e5b9ull;
  h ^= h >> 31;
  h *= 0x94d049bb133111ebull;
  h ^= h >> 29;
  return (h ^ (h >> 4) ^ (h >> 8) ^ (h >> 12)) & 0xF;
}

inline bool EdgeIn(int32_t code, uint64_t& out) {
  if (code == -1) out = 0;
  else if (code == -2) out = 1;
  else if (code >= 0 && code <= 61) out = static_cast<uint64_t>(code) + 2;
  else return false;
  return true;
}
inline int32_t EdgeOut(uint64_t v) { return v == 0 ? -1 : v == 1 ? -2 : static_cast<int32_t>(v) - 2; }

inline bool Encode(const TileMsg& m, uint64_t& word) {
  uint64_t n, w;
  if (m.x < 0 || m.x > 255 || m.y < 0 || m.y > 255 || m.seen < 0 || m.seen > 511 || !EdgeIn(m.north, n) || !EdgeIn(m.west, w))
    return false;
  const uint64_t bed = m.next_pearl >= 0, next = m.next_pearl < 0 ? 0 : static_cast<uint64_t>(m.next_pearl > 511 ? 511 : m.next_pearl);
  uint64_t p = kTypeTile;
  p |= static_cast<uint64_t>(m.x) << 2;
  p |= static_cast<uint64_t>(m.y) << 10;
  p |= n << 18;
  p |= w << 24;
  p |= bed << 30;
  p |= next << 31;
  p |= static_cast<uint64_t>(m.pearl) << 40;
  p |= static_cast<uint64_t>(m.seen) << 41;
  word = (p << 4) | Tag(p);   // 50 + 4 = 54 bits
  static_assert(50 + 4 <= kWordBits);
  return true;
}

inline bool Decode(uint64_t word, TileMsg& m) {
  if (word >> kWordBits) return false;
  const uint64_t p = word >> 4;
  if ((word & 0xF) != Tag(p) || (p & 3) != kTypeTile) return false;
  m.x = static_cast<int32_t>(p >> 2 & 0xFF);
  m.y = static_cast<int32_t>(p >> 10 & 0xFF);
  m.north = EdgeOut(p >> 18 & 0x3F);
  m.west = EdgeOut(p >> 24 & 0x3F);
  m.next_pearl = (p >> 30 & 1) ? static_cast<int32_t>(p >> 31 & 0x1FF) : -1;
  m.pearl = p >> 40 & 1;
  m.seen = static_cast<int32_t>(p >> 41 & 0x1FF);
  return true;
}

struct QueenMsg {
  int32_t x = 0, y = 0, round = 0, home_x = 0, home_y = 0;
  bool distress = false;   // she has no move that lasts: workers near her make room
};

inline bool Encode(const QueenMsg& m, uint64_t& word) {
  if (m.x < 0 || m.x > 255 || m.y < 0 || m.y > 255 || m.round < 0 || m.round > 511 || m.home_x < 0 || m.home_x > 255 ||
      m.home_y < 0 || m.home_y > 255)
    return false;
  const uint64_t p = kTypeQueen | static_cast<uint64_t>(m.x) << 2 | static_cast<uint64_t>(m.y) << 10 |
                     static_cast<uint64_t>(m.round) << 18 | static_cast<uint64_t>(m.home_x) << 27 |
                     static_cast<uint64_t>(m.home_y) << 35 | static_cast<uint64_t>(m.distress) << 43;
  word = (p << 4) | Tag(p);
  return true;
}

inline bool Decode(uint64_t word, QueenMsg& m) {
  if (word >> kWordBits) return false;
  const uint64_t p = word >> 4;
  if ((word & 0xF) != Tag(p) || (p & 3) != kTypeQueen || (p >> 44)) return false;
  m.x = static_cast<int32_t>(p >> 2 & 0xFF);
  m.y = static_cast<int32_t>(p >> 10 & 0xFF);
  m.round = static_cast<int32_t>(p >> 18 & 0x1FF);
  m.home_x = static_cast<int32_t>(p >> 27 & 0xFF);
  m.home_y = static_cast<int32_t>(p >> 35 & 0xFF);
  m.distress = p >> 43 & 1;
  return true;
}

// Position message: where dragon `id` of our team had its head at `round`.
//   pos: tag 4 | type 2 (3) | x 8 | y 8 | round 9 | id 7                                (38 bits)
struct PosMsg {
  int32_t x = 0, y = 0, round = 0, id = 0;
};

inline bool Encode(const PosMsg& m, uint64_t& word) {
  if (m.x < 0 || m.x > 255 || m.y < 0 || m.y > 255 || m.round < 0 || m.round > 511 || m.id < 0 || m.id > 127) return false;
  const uint64_t p = 3 | static_cast<uint64_t>(m.x) << 2 | static_cast<uint64_t>(m.y) << 10 |
                     static_cast<uint64_t>(m.round) << 18 | static_cast<uint64_t>(m.id) << 27;
  word = (p << 4) | Tag(p);
  return true;
}

inline bool Decode(uint64_t word, PosMsg& m) {
  if (word >> kWordBits) return false;
  const uint64_t p = word >> 4;
  if ((word & 0xF) != Tag(p) || (p & 3) != 3 || (p >> 34)) return false;
  m.x = static_cast<int32_t>(p >> 2 & 0xFF);
  m.y = static_cast<int32_t>(p >> 10 & 0xFF);
  m.round = static_cast<int32_t>(p >> 18 & 0x1FF);
  m.id = static_cast<int32_t>(p >> 27 & 0x7F);
  return true;
}

// Threat message: an enemy non-queen head was seen at (x, y) at `round` (the lunge hunters).
//   threat: tag 4 | type 2 (0) | x 8 | y 8 | round 9                                    (31 bits)
struct ThreatMsg {
  int32_t x = 0, y = 0, round = 0;
};

inline bool Encode(const ThreatMsg& m, uint64_t& word) {
  if (m.x < 0 || m.x > 255 || m.y < 0 || m.y > 255 || m.round < 0 || m.round > 511) return false;
  const uint64_t p = 1ull << 30 | static_cast<uint64_t>(m.x) << 2 | static_cast<uint64_t>(m.y) << 10 | static_cast<uint64_t>(m.round) << 18;
  word = (p << 4) | Tag(p);
  return true;
}

inline bool Decode(uint64_t word, ThreatMsg& m) {
  if (word >> kWordBits) return false;
  const uint64_t p = word >> 4;
  if ((word & 0xF) != Tag(p) || (p & 3) != 0 || (p >> 27 & 7) != 0 || !(p >> 30 & 1) || (p >> 31)) return false;
  m.x = static_cast<int32_t>(p >> 2 & 0xFF);
  m.y = static_cast<int32_t>(p >> 10 & 0xFF);
  m.round = static_cast<int32_t>(p >> 18 & 0x1FF);
  return true;
}

}  // namespace sonar
