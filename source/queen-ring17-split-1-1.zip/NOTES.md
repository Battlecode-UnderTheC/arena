# queen-ring17-split-1

Parent: queen-ring17-hunt-3-1. Replay finding: the current #1 bot splits at the same rate per dragon-round
in its wins and losses before round 100, but after round 100 its losses split about 40 percent less
(2.5 vs 4.0 per 100 dragon-rounds). The gate that blocks splits is SplitSafe, which requires both the
child and the parent to have escape room. Change: from round 100 only the child needs room.
