#include "strategy.hpp"
#include <algorithm>
#include <functional>
#include <set>
namespace gm2 {
int StrategyAgent::InsightDistance(int a,int b) const{
 int dx=std::abs(board_.X(a)-board_.X(b)),dy=std::abs(board_.Y(a)-board_.Y(b));
 return std::min(dx,board_.width()-dx)+std::min(dy,board_.height()-dy);
}
void StrategyAgent::InsightCommit(const bot::Action&a){
 if(IsQueen())return;
 insight_expected_=length_;
 if(a.kind==bot::Action::kSplit&&!a.resign)insight_expected_-=a.split;
 if(a.kind==bot::Action::kMove&&!a.resign)insight_expected_-=std::max(0,int(a.steps.size())-(length_+3)/4);
}
void StrategyAgent::InsightObserve(const rl::Observation&o){
 if(IsQueen())return;
 const int ate=insight_expected_<0?0:std::max(0,length_-insight_expected_);
 if(ate)insight_food_.push_back({round_,ate});
 while(!insight_food_.empty()&&insight_food_.front().first<=round_-12)insight_food_.pop_front();
 while(!insight_failures_.empty()&&insight_failures_.front().first<=round_-12)insight_failures_.pop_front();
 if(INSIGHT_MODE==2&&insight_target_>=0&&insight_target_round_==round_-1&&board_.Current(insight_target_)){
  const auto&m=board_.at(insight_target_);
  if(!m.pearl&&m.occupant>=0&&m.occupant!=spawn_.id&&m.occupant_head){
   auto w=seen_.find(m.occupant);
   if(w!=seen_.end()&&w->second.team==spawn_.team&&w->second.round==round_){
    insight_failures_.push_back({round_,insight_target_});int nearby=0;
    for(const auto&f:insight_failures_)if(InsightDistance(f.second,insight_target_)<=3)++nearby;
    if(nearby>=3&&insight_food_.empty()){insight_avoid_=insight_target_;insight_avoid_until_=round_+8;}
   }
  }
 }
 if(ate){insight_avoid_until_=-1;insight_failures_.clear();}
 insight_target_=-1;
 insight_queen_body_.clear();
 if(INSIGHT_MODE==4&&queen_id_>=0){
  for(const auto&s:o.segments)if(s.id==queen_id_)insight_queen_body_.push_back(board_.Tile(s.x,s.y));
 }
}
bool StrategyAgent::InsightProducer() const{
 if(INSIGHT_MODE!=1||round_>=430||length_<4||int(body_.size())!=length_||insight_food_.empty()||round_-insight_food_.back().first>=8)return false;
 int food=0;for(auto f:insight_food_)food+=f.second;if(food<3)return false;
 const auto paths=Search(board_,head_,[&](int t){return !Occupied(t);},4);
 bool nearby=false;for(int t=0;t<board_.size();++t)if(paths.dist[t]>0&&board_.at(t).pearl&&!Banned(t))nearby=true;
 if(!nearby)return false;
 for(const auto&[id,w]:seen_)if(id!=spawn_.id&&w.team==spawn_.team&&w.round==round_&&w.head>=0&&InsightDistance(w.head,head_)<=6&&
   (w.length>length_||(w.length==length_&&id<spawn_.id)))return false;
 std::vector<int>b(body_.begin(),body_.end());
 return EscapeLevel(b,EscapeCap(length_))>0;
}
double StrategyAgent::InsightRouteValue(int goal) const{
 if(INSIGHT_MODE!=3||IsQueen()||length_<8||int(body_.size())!=length_)return 1.0;
 int budget=384;bool continuation=false,cycle=false;
 std::function<void(std::vector<int>,std::vector<int>,int,int)>walk;
 walk=[&](std::vector<int>b,std::vector<int>eaten,int depth,int arrived){
  if(--budget<0||cycle)return;
  if(arrived>=0&&depth-arrived>=3){continuation=true;if(depth-arrived>=std::min(16,length_+2))return;}
  if(arrived<0&&depth>=6)return;
  for(int dir=0;dir<4&&budget>0;++dir){int t=board_.Step(b.front(),dir);
   if(t<0||std::find(b.begin(),b.end(),t)!=b.end())continue;
   if(board_.Current(t)&&board_.at(t).occupant>=0&&board_.at(t).occupant!=spawn_.id)continue;
   if(Exposed(t))continue;
   const bool eat=board_.at(t).pearl&&std::find(eaten.begin(),eaten.end(),t)==eaten.end();
   auto next=b;next.insert(next.begin(),t);auto ne=eaten;
   if(eat)ne.push_back(t);else next.pop_back();
   int hit=arrived;if(hit<0&&t==goal)hit=depth+1;
   if(hit>=0&&t==goal&&depth+1>hit){cycle=true;continuation=true;return;}
   walk(std::move(next),std::move(ne),depth+1,hit);
  }
 };
 walk(std::vector<int>(body_.begin(),body_.end()),{},0,-1);
 // Budget exhaustion is uncertainty, not proof that a route is impossible.
 if(budget<=0&&!continuation)return 1.0;
 return cycle?1.2:continuation?1.0:0.05;
}
bool StrategyAgent::InsightCollectible() const{
 if(INSIGHT_MODE!=4)return true;
 if(int(body_.size())!=length_||insight_queen_body_.size()<2)return false;
 auto q=seen_.find(queen_id_);
 if(q==seen_.end()||q->second.round!=round_||q->second.partial||q->second.team!=spawn_.team||q->second.head!=insight_queen_body_.front()||int(insight_queen_body_.size())!=q->second.length)return false;
 std::set<int>deposits;for(int i=0;i<length_;i+=2)if(!board_.at(body_[i]).pearl)deposits.insert(body_[i]);
 if(deposits.size()<2)return false;
 std::vector<Paths>rivals;std::vector<int>speeds;
 auto open=[&](int t){const auto&m=board_.at(t);return !board_.Current(t)||m.occupant<0||m.occupant==spawn_.id||m.occupant==queen_id_;};
 for(const auto&[id,w]:seen_)if(id!=spawn_.id&&id!=queen_id_&&w.team==spawn_.team&&w.round==round_&&w.head>=0){rivals.push_back(Search(board_,w.head,open,6));speeds.push_back(std::max(1,(w.length+3)/4));}
 struct State{std::vector<int>body,eaten;int supplied=0;};
 std::vector<State>beam{{insight_queen_body_,{},0}};
 auto viable=[&](const State&s,int t){return t>=0&&std::find(s.body.begin(),s.body.end(),t)==s.body.end()&&open(t)&&!Exposed(t);};
 for(int turn=1;turn<=3;++turn){
  std::vector<State>ends;for(auto root:beam){std::vector<State>steps{root};const int allowance=std::min(4,(int(root.body.size())+3)/4);
   for(int step=0;step<allowance;++step){std::vector<State>next;
    for(const auto&s:steps)for(int dir=0;dir<4;++dir){int t=board_.Step(s.body.front(),dir);if(!viable(s,t))continue;
     State n=s;bool fresh=std::find(n.eaten.begin(),n.eaten.end(),t)==n.eaten.end();bool eat=fresh&&(deposits.count(t)||board_.at(t).pearl);
     n.body.insert(n.body.begin(),t);if(eat)n.eaten.push_back(t);else n.body.pop_back();
     if(fresh&&deposits.count(t)){bool claimed=false;for(size_t i=0;i<rivals.size();++i)if(rivals[i].dist[t]>=0&&rivals[i].dist[t]<=turn*speeds[i])claimed=true;if(!claimed)++n.supplied;}
     if(n.supplied>=2){for(int d=0;d<4;++d)if(viable(n,board_.Step(t,d)))return true;}
     next.push_back(std::move(n));
    }
    std::stable_sort(next.begin(),next.end(),[](const State&a,const State&b){return a.supplied>b.supplied;});if(next.size()>16)next.resize(16);
    ends.insert(ends.end(),next.begin(),next.end());steps=std::move(next);if(steps.empty())break;
   }
  }
  std::stable_sort(ends.begin(),ends.end(),[](const State&a,const State&b){return a.supplied>b.supplied;});if(ends.size()>16)ends.resize(16);beam=std::move(ends);if(beam.empty())return false;
 }
 return false;
}
}
