// g43-6 (ring-founder-1): founder dispatch on small starts (see strategy.hpp, kFounderUnits).
//
// A founder walks to the largest pearl region it has seen that it reaches no later than any enemy
// head seen in the last kRivalMemory rounds (the contest's rival test, RivalDist), and holds back
// from regions an enemy head is nearer to. A region is the pearls (as last seen) linked within
// kRegionLink of each other; its size is their count. Live pearls only, not soon-due beds: on maps
// where every tile is a slow bed (Colosseum's rim, gap up to 250) a few due beds lie around any
// spawn and would make home a region (iteration 1: the founder "arrived" at home on its first
// turn). With no region of kRegionMin pearls (one pearl is food, not a place to settle) it
// explores the frontier as the starters' explorers do (RushGoal: food within 2 first).
// Observation only: no map keys, no fixed board points.
#include <algorithm>
#include <cstdio>

#include "strategy.hpp"

namespace gm2 {
using namespace strat;

namespace {
constexpr double kRegionMin = 2.0;   // rush.cpp's kClusterMin: two live beds are worth farming
constexpr size_t kMaxBeds = 400;
constexpr int32_t kView3 = 3;        // the 7x7 view's half-width
constexpr int32_t kStaleCap = 30;    // a tile unseen this long is as good as never seen (a slow bed's countdown scale, rush.cpp BedWeight)
constexpr int32_t kStaleReach = 20;  // CPU bound: candidate tiles within 20 steps     // CPU bound on the region grouping (pairs: 160k at most)
}  // namespace

int32_t StrategyAgent::FounderGoal(const Paths& paths, bool* here) {
  *here = false;
  founder_in_region_ = false;
  std::vector<int32_t> beds;
  for (int32_t t = 0; t < board_.size() && beds.size() < kMaxBeds; ++t)
    if (board_.at(t).seen_round >= 0 && board_.at(t).pearl && !Banned(t)) beds.push_back(t);
  // regions: connected components of beds linked within kRegionLink
  std::vector<int32_t> region(beds.size(), -1);
  int32_t regions = 0;
  for (size_t i = 0; i < beds.size(); ++i) {
    if (region[i] >= 0) continue;
    region[i] = regions;
    std::vector<size_t> queue{i};
    for (size_t qi = 0; qi < queue.size(); ++qi)
      for (size_t j = 0; j < beds.size(); ++j)
        if (region[j] < 0 && Torus(beds[queue[qi]], beds[j]) <= kRegionLink) {
          region[j] = regions;
          queue.push_back(j);
        }
    ++regions;
  }
  // iteration 6: the rivals' walking distance over the known board (kelp blocks, bodies don't), not
  // the torus distance: on Colosseum the enemy's home pocket touches ours across the board's wrap
  // behind kelp, so by torus distance every pearl in our pocket was "theirs first" (theirs 0-2 at
  // r8-13, seed 1592614637) and the founder held back from all of them.
  std::vector<int32_t> rival(board_.size(), 1 << 20);
  {
    std::vector<int32_t> dist(board_.size()), queue;
    for (const auto& [id, w] : seen_) {
      if (w.team == spawn_.team || w.head < 0 || round_ - w.round > kRivalMemory) continue;
      std::fill(dist.begin(), dist.end(), -1);
      queue.assign(1, w.head);
      dist[w.head] = 0;
      for (size_t qi = 0; qi < queue.size(); ++qi) {
        const int32_t u = queue[qi];
        rival[u] = std::min(rival[u], RivalDist(dist[u], round_ - w.round));
        for (int dir = 0; dir < 4; ++dir) {
          const int32_t n = board_.Step(u, dir);
          if (n < 0 || dist[n] >= 0) continue;
          dist[n] = dist[u] + 1;
          queue.push_back(n);
        }
      }
    }
  }
  struct Region {
    int32_t size = 0, ours = 1 << 20, theirs = 1 << 20, near = -1;
  };
  std::vector<Region> r(regions);
  for (size_t i = 0; i < beds.size(); ++i) {
    Region& g = r[region[i]];
    const int32_t t = beds[i];
    ++g.size;
    const int32_t d = paths.dist[t];
    if (d >= 0 && d < g.ours) {
      g.ours = d;
      g.near = t;
    }
    g.theirs = std::min(g.theirs, rival[t]);
  }
  int32_t best = -1;
  for (int32_t k = 0; k < regions; ++k) {
    const Region& g = r[k];
    if (g.near < 0 || g.size < kRegionMin || g.ours > g.theirs) continue;   // unreachable, small, or theirs first
    // iteration 2: standing in any such region counts as arrived. With arrival only at the largest
    // one, founders crossed a rich region at length 4 without splitting (duel-eb6b54e5 trophy
    // games 6-7: the founder reached 4 in the cup at r30 and walked on to a larger one, unsplit,
    // while the base's child split there; 3 v 4 dragons at r10, 5 v 8 at r30).
    // iteration 6: ... but it only splits there and walks on to the largest: farming any 2-pearl
    // spot as "arrived" kept it in its home pocket (Colosseum seeds 11, 44: to r20+)
    if (g.ours <= kArrive) founder_in_region_ = true;
    if (best < 0 || g.size > r[best].size || (g.size == r[best].size && g.ours < r[best].ours)) best = k;
  }
#if 0
  for (int32_t k = 0; k < regions; ++k) std::fprintf(stderr, "  reg size%d ours%d theirs%d near%d,%d\n", r[k].size, r[k].ours, r[k].theirs, r[k].near>=0?board_.X(r[k].near):-1, r[k].near>=0?board_.Y(r[k].near):-1);
  std::fprintf(stderr, "FG r%d id%d beds%zu regions%d best%d size%d ours%d theirs%d here%d\n", round_, spawn_.id, beds.size(), regions, best,
               best >= 0 ? r[best].size : -1, best >= 0 ? r[best].ours : -1, best >= 0 ? r[best].theirs : -1, int(*here));
#endif
  if (best >= 0) {
    founder_way_ = -1;
    if (r[best].ours <= kArrive) {
      *here = true;   // there: it farms (ChooseGoal) and splits at 4, which ends the dispatch (strategy.cpp)
      return -1;
    }
    return r[best].near;   // on the way; in a smaller region on the way it may split (strategy.cpp)
  }
  // no region yet: the nearest lone pearl it reaches first (iteration 5: on Colosseum, seed 11, the
  // frontier walk dithered in the home corner for 18 rounds while lone pearls lay 5-8 steps away
  // towards the fast beds; eating one shows the next part of the board), else the frontier
  // iteration 6: no region yet, keep the way-goal chosen earlier while it stands (reachable, not
  // reached, a pearl still there if it was one). Local Colosseum seed 11: re-choosing every turn the
  // founder flipped between pocket frontier tiles, a lone pearl and the mouth for 12 rounds.
  if (founder_way_ >= 0 && paths.dist[founder_way_] > 0 && (!founder_way_pearl_ || board_.at(founder_way_).pearl)) {
#ifdef FOUNDER_DBG
    std::fprintf(stderr, "FG r%d id%d sticky%d d%d first%d\n", round_, spawn_.id, founder_way_, paths.dist[founder_way_], int(paths.first[founder_way_]));
#endif
    return founder_way_;
  }
  int32_t food = -1;
  for (int32_t k = 0; k < regions; ++k) {
    const Region& g = r[k];
    if (g.near >= 0 && g.ours > 0 && g.ours <= g.theirs && (food < 0 || g.ours < r[food].ours)) food = k;
  }
  int32_t g = food >= 0 ? r[food].near : RushGoal(paths);
  // iteration 6: no frontier walk (RushGoal). With the map's symmetry inferred, the mirror fills
  // most of memory in a few rounds, so the frontier runs out or is left only at the back of the
  // home pocket (arena 184321, Colosseum seat B: the founder circled the pocket to r28 with
  // RushGoal -1 on 9 of 20 turns; locally, seed 44, it walked back to a pocket-corner frontier tile).
  // New pearls grow where nobody has looked lately, so it walks to the view with the most stale
  // tiles (last seen longest ago, capped at kStaleCap; never seen counts as the cap) per step.
  if (g < 0) {
    double best_score = 0;
    for (int32_t t = 0; t < board_.size(); ++t) {
      const int32_t d = paths.dist[t];
      if (d <= 0 || d > kStaleReach || Banned(t) || Classify(t) != Cell::kFree) continue;
      int32_t stale = 0;
      const int32_t x = board_.X(t), y = board_.Y(t);
      for (int32_t ey = -kView3; ey <= kView3; ++ey)
        for (int32_t ex = -kView3; ex <= kView3; ++ex) {
          const int32_t v = board_.Tile(x + ex, y + ey);
          if (paths.dist[v] < 0) continue;   // behind kelp (or a body): not ground it opens up
          const int32_t sr = board_.at(v).seen_round;
          stale += sr < 0 ? kStaleCap : std::min(kStaleCap, round_ - sr);
        }
      const double score = stale / (d + 1.0);
      if (score > best_score) best_score = score, g = t;
    }
  }
#ifdef FOUNDER_DBG
  std::fprintf(stderr, "FG r%d id%d food%d rush%d\n", round_, spawn_.id, food, g);
#endif
  founder_way_ = g;
  founder_way_pearl_ = g >= 0 && board_.at(g).pearl;
  return g;
}

}  // namespace gm2
