# queen-ring17-hunt-1

Parent: queen-ring17-first-then-grow-1 (current arena #1). Same hunt as queen-ring14-hunt-1: spare workers
path to the enemy queen last-known tile; outnumbered guard kept except before round 80.
