// ring-realsched: the team job scheduler (design: syeyoung-tokens.league/strategy/realsched-design.md).
//
// Every non-queen worker, every turn, before the late endgame, computes one team-wide assignment of
// jobs to the workers it knows about and takes its own:
//  - EAT(t): a pearl or a bed ripe on arrival within kJobHorizon rounds; capacity 1.
//  - FIELD(b): an 8x8 block holding 2+ known beds and no enemy head; capacity ceil(beds/2).
//  - CONTEST(b): the same with enemy heads in it (seen <= 20 rounds ago, or reported by a FIELD
//    word); capacity their heads + 1. A block they hold (their heads >= ours + 2) has no job.
//  - SCOUT(b): the unseen tiles of a block, reached through a frontier tile; capacity 1. Value
//    w(round) * min(1, unseen/24) * (1 + 0.5 m(b)), m the middle prior (Middle()), which the
//    observation cuts to 0: a block mostly seen with < 2 beds, a block the enemy holds.
//  - STALE (fallback, unassigned): the reachable tile longest unseen (60+ rounds); else no goal
//    (SafeStep's roomiest step).
// Participants: this worker, allies in view (breadth-first arrival times within kJobHorizon, a torus
// estimate beyond), up to kJobMaxParts. Allies heard in a JOB word at most kJobHeard rounds old and
// not in view hold their claims (capacity taken first). Utility V/(T+1), x kJobKeep for the job a
// worker already holds; filled greedily with ties by (id, key), so allies that see the same group
// agree without messages, and JOB claims settle the rest.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <tuple>

#include "strategy.hpp"

#ifdef JOB_DBG
#include <atomic>
#include <cstdio>
namespace gm2 {
std::atomic<long> g_job_double{0}, g_job_eat_turns{0}, g_job_heard_job{0}, g_job_heard_field{0}, g_job_cut_empty{0},
    g_job_cut_held{0}, g_job_scout_mid{0}, g_job_scout_turns{0}, g_job_giveup{0}, g_job_scout_empty{0}, g_job_overflow{0};
}
#endif

namespace gm2 {
using namespace strat;

namespace {
constexpr uint64_t kJobMagic = 0xC1, kFieldMagic = 0xC2;
constexpr int32_t kRivalFresh = 20;     // an enemy head seen this recently still holds its block
constexpr int32_t kStaleAge = 60;
constexpr int32_t kLiveBed = 30;
constexpr int32_t kPatrolAge = 20;     // a block's ground unseen this long is worth a patrol
#ifndef JOB_PATROLW
#define JOB_PATROLW 0.5
#endif       // as BedWeight: a bed due within 30 rounds       // the fallback: ground unseen this long
constexpr int32_t kScoutStall = 6, kScoutBan = 30;
constexpr double kScoutFull = 24.0;     // unseen tiles in a block worth a full scout
#ifndef JOB_SCOUTW
#define JOB_SCOUTW 0.3
#endif
#ifndef JOB_SCOUTMID
#define JOB_SCOUTMID 0.6
#endif
double ScoutWeight(int32_t round) { return round < 40 ? JOB_SCOUTW : round < 150 ? JOB_SCOUTMID : round < 300 ? 0.6 * JOB_SCOUTMID : 0.4 * JOB_SCOUTMID; }
}  // namespace

// The middle: the midpoint of our home and its mirror (the enemy's home, once the symmetry is
// known), on the shorter way round the torus; the board centre until then.
int32_t StrategyAgent::Middle() const {
  const int32_t w = board_.width(), h = board_.height();
  const int32_t m = job_home_ >= 0 ? sym_.Mirror(job_home_) : -1;
  if (m < 0 || m == job_home_) return board_.Tile(w / 2, h / 2);
  auto mid = [](int32_t a, int32_t b, int32_t n) {
    int32_t d = ((b - a) % n + n) % n;
    if (d > n / 2) d -= n;
    return ((a + d / 2) % n + n) % n;
  };
  return board_.Tile(mid(board_.X(job_home_), board_.X(m), w), mid(board_.Y(job_home_), board_.Y(m), h));
}

void StrategyAgent::HearJobs(const rl::Observation& o) {
  for (const uint64_t w : o.inbox) {
    const uint64_t magic = w >> 56;
    if ((magic != kJobMagic && magic != kFieldMagic) || int32_t((w >> 55) & 1) != (spawn_.team & 1)) continue;
    if (magic == kJobMagic) {
      // id10 kind3 tx6 ty6 hx6 hy6 t4 len5 round9
      const int32_t id = int32_t((w >> 45) & 1023), kind = int32_t((w >> 42) & 7);
      const int32_t tx = int32_t((w >> 36) & 63), ty = int32_t((w >> 30) & 63), hx = int32_t((w >> 24) & 63), hy = int32_t((w >> 18) & 63);
      const int32_t t = int32_t((w >> 14) & 15), len = int32_t((w >> 9) & 31), r = int32_t(w & 511);
      if (r > round_ || tx >= board_.width() || ty >= board_.height() || hx >= board_.width() || hy >= board_.height()) continue;
      if (id == (spawn_.id & 1023)) continue;
#ifdef JOB_DBG
      ++g_job_heard_job;
#endif
      JobClaim& c = job_heard_[id];
      if (r < c.round) continue;
      c.kind = kind;
      c.target = board_.Tile(tx, ty);
      c.key = kind == kJobEat ? (kind << 20) | c.target : (kind << 20) | Block(c.target);
      c.head = board_.Tile(hx, hy);
      c.t = t;
      c.length = len;
      c.round = r;
    } else {
      // x6 y6 beds5 ours4 theirs4 round9 due6
      const int32_t x = int32_t((w >> 49) & 63), y = int32_t((w >> 43) & 63), r = int32_t((w >> 21) & 511);
      if (r > round_ || x >= board_.width() || y >= board_.height()) continue;
#ifdef JOB_DBG
      ++g_job_heard_field;
#endif
      const int32_t tile = board_.Tile(x, y);
      FieldInfo& f = fields_[Block(tile)];
      if (r <= f.round) continue;
      f.tile = tile;
      f.beds = int32_t((w >> 38) & 31);
      f.ours = int32_t((w >> 34) & 15);
      f.theirs = int32_t((w >> 30) & 15);
      f.round = r;
      f.due = int32_t((w >> 15) & 63);
    }
  }
}

uint64_t StrategyAgent::JobWord() const {
  const int32_t tgt = job_now_ && job_target_ >= 0 ? job_target_ : head_;
  const uint64_t kind = job_now_ ? uint64_t(job_kind_ & 7) : 0;
  return (kJobMagic << 56) | (uint64_t(spawn_.team & 1) << 55) | (uint64_t(spawn_.id & 1023) << 45) | (kind << 42) |
         (uint64_t(board_.X(tgt) & 63) << 36) | (uint64_t(board_.Y(tgt) & 63) << 30) | (uint64_t(board_.X(head_) & 63) << 24) |
         (uint64_t(board_.Y(head_) & 63) << 18) | (uint64_t(std::min(job_t_, 15)) << 14) | (uint64_t(std::min(length_, 31)) << 9) |
         uint64_t(round_ & 511);
}

// our own block's report on even calls, a relay of a fresh one heard on odd calls
uint64_t StrategyAgent::FieldWord() {
  const int32_t own = Block(head_);
  int32_t key = own;
  if ((field_relay_++ & 1) && fields_.size() > 1) {
    std::vector<int32_t> fresh;
    for (const auto& [b, f] : fields_)
      if (b != own && round_ - f.round <= 30) fresh.push_back(b);
    if (!fresh.empty()) {
      std::sort(fresh.begin(), fresh.end());
      key = fresh[(field_relay_ / 2) % fresh.size()];
    }
  }
  const auto it = fields_.find(key);
  if (it == fields_.end()) return 0;
  const FieldInfo& f = it->second;
  return (kFieldMagic << 56) | (uint64_t(spawn_.team & 1) << 55) | (uint64_t(board_.X(f.tile) & 63) << 49) |
         (uint64_t(board_.Y(f.tile) & 63) << 43) | (uint64_t(std::min(f.beds, 31)) << 38) | (uint64_t(std::min(f.ours, 15)) << 34) |
         (uint64_t(std::min(f.theirs, 15)) << 30) | (uint64_t(f.round & 511) << 21) | (uint64_t(std::clamp(f.due, 0, 63)) << 15);
}

StrategyAgent::Goal StrategyAgent::JobGoal(const Paths& paths) {
  job_now_ = false;
  const int32_t n = board_.size(), nb = BlockCount();
  // home: where our queen was first known to be (her report), else where we first stood
  if (job_home_ < 0) {
    if (queen_id_ >= 0)
      if (const auto q = reports_.find(queen_id_); q != reports_.end() && q->second.length > 0 && q->second.tile >= 0) job_home_ = q->second.tile;
    if (job_home_ < 0 && round_ >= 10) job_home_ = head_;
  }
  // tiles seen (for the scout's give-up)
  int32_t seen = 0;
  for (int32_t t = 0; t < n; ++t) seen += board_.at(t).seen_round >= 0;
  if (seen > seen_total_) seen_total_ = seen, seen_grow_round_ = round_;

  std::vector<uint8_t> mine_mask(n, 0);
  for (const int32_t t : body_)
    if (t >= 0) mine_mask[t] = 1;
  auto occ = [&](int32_t t) { return mine_mask[t] != 0 || (board_.Current(t) && board_.at(t).occupant >= 0); };
  // food values (as ChooseGoal's base), and the queen's ground kept for her late
  std::vector<double> base(n, 0.0);
  std::vector<int32_t> due0(n, 0);
  std::vector<int32_t> food;
  for (int32_t t = 0; t < n; ++t) {
    int32_t r;
    base[t] = (RING5_MODE == 3 && Ring5Reserved(t)) ? 0 : TileValue(t, 0, &r, occ(t));
    const TileMemory& m = board_.at(t);
    if (base[t] > 0 && !m.pearl) due0[t] = std::max(0, m.countdown - (round_ - m.seen_round));
  }
  if (kReserve > 0 && round_ >= p_.feed_from_round) {
    const Report champ = Champion();
    if (champ.id >= 0 && champ.id != spawn_.id && round_ - champ.round <= kReserveFresh && champ.tile >= 0) {
      int32_t c = champ.tile;
      if (const auto it = seen_.find(champ.id); it != seen_.end() && it->second.round == round_ && it->second.head >= 0) c = it->second.head;
      for (int32_t t = 0; t < n; ++t)
        if (base[t] > 0 && board_.at(t).pearl && Torus(t, c) <= kReserve) base[t] = 0;
    }
  }
  for (int32_t t = 0; t < n; ++t)
    if (base[t] > 0) food.push_back(t);

  // participants: us, then allies in view by distance
  struct Part { int32_t id, head; std::vector<int32_t> dist; };
  std::vector<Part> parts;
  parts.push_back({spawn_.id, head_, {}});
  {
    std::vector<std::pair<int32_t, int32_t>> near;   // (torus dist, id)
    for (const auto& [id, w] : seen_)
      if (w.team == spawn_.team && w.round == round_ && w.head >= 0 && id != spawn_.id && id > 1 && w.head != head_)
        near.push_back({Torus(head_, w.head), id});
    std::sort(near.begin(), near.end());
    for (const auto& [d, id] : near) {
#ifdef JOB_SOLO
      break;
#endif
      if (static_cast<int32_t>(parts.size()) >= kJobMaxParts) break;
      parts.push_back({id, seen_.at(id).head, {}});
    }
  }
  // allies' arrival times within the horizon
  for (size_t i = 1; i < parts.size(); ++i) {
    Part& p = parts[i];
    p.dist.assign(n, -1);
    sched_queue_.clear();
    sched_queue_.push_back(p.head);
    p.dist[p.head] = 0;
    for (size_t qi = 0; qi < sched_queue_.size(); ++qi) {
      const int32_t t = sched_queue_[qi], d = p.dist[t];
      ++work_;
      if (d >= kJobHorizon) continue;
      for (int dir = 0; dir < 4; ++dir) {
        const int32_t m = board_.Step(t, dir);
        if (m < 0 || p.dist[m] >= 0 || occ(m)) continue;
        p.dist[m] = d + 1;
        sched_queue_.push_back(m);
      }
    }
  }
  // a participant's steps to t: exact for us, the search or a torus estimate for an ally (only to
  // tiles we reach: what we can't reach we don't schedule)
  auto dist_of = [&](size_t i, int32_t t, bool estimate) -> int32_t {
    if (i == 0) return paths.dist[t];
    const int32_t d = parts[i].dist[t];
    if (d >= 0) return d;
    if (!estimate || paths.dist[t] < 0) return -1;
    return std::max(kJobHorizon + 1, (Torus(parts[i].head, t) * 13 + 9) / 10);
  };
  // heard claims of allies not in view
  std::unordered_map<int32_t, int32_t> used;   // job key -> places taken
  std::unordered_map<int32_t, int32_t> heard_key;   // ally id -> its claimed key (for the keep bonus)
  for (const auto& [id, c] : job_heard_) {
    if (round_ - c.round > kJobHeard || c.kind == 0) continue;
#ifdef JOB_SOLO
    continue;
#endif
    heard_key[id] = c.key;
    bool in_view = false;
    for (const Part& p : parts) in_view |= (p.id & 1023) == id;
    if (!in_view) ++used[c.key];
  }
  // enemy heads in view (they take food they reach first) and recently seen (they hold blocks)
  std::vector<int32_t> enemy_now;
  std::vector<int32_t> theirs_in(nb, 0), ours_in(nb, 0);
  for (const auto& [id, w] : seen_) {
    if (w.head < 0) continue;
    if (w.team != spawn_.team) {
      if (w.round == round_) enemy_now.push_back(w.head);
      if (round_ - w.round <= kRivalFresh) ++theirs_in[Block(w.head)];
    } else if (w.round == round_) {
      ++ours_in[Block(w.head)];
    }
  }
  ++ours_in[Block(head_)];
  for (const auto& [id, c] : job_heard_)
    if (round_ - c.round <= kJobHeard && c.head >= 0) {
      bool in_view = false;
      for (const Part& p : parts) in_view |= (p.id & 1023) == id;
      if (!in_view) ++ours_in[Block(c.head)];
    }
  for (int32_t b = 0; b < nb; ++b)
    if (const auto f = fields_.find(b); f != fields_.end() && round_ - f->second.round <= kRivalFresh)
      theirs_in[b] = std::max(theirs_in[b], f->second.theirs);

  // per-block facts: beds, unseen tiles, frontier tiles
  std::vector<int32_t> beds(nb, 0), unseen(nb, 0), btiles(nb, 0), bed_seen(nb, -1);
  std::vector<std::vector<int32_t>> bed_tiles(nb), frontier(nb);
  for (int32_t t = 0; t < n; ++t) {
    const int32_t b = Block(t);
    ++btiles[b];
    const TileMemory& m = board_.at(t);
    // the frontier: a tile we reach (often just past the view: its edge towards us was seen) with
    // an edge never seen
    if (paths.dist[t] > 0 && !occ(t) && !Banned(t))
      for (int d = 0; d < 4; ++d) {
        if (board_.Step(t, d) != kUnknown) continue;
        if (portal_[t] >> d & 1) {
          if (WillCross()) frontier[b].push_back(t), unseen[b] += 4;
          break;
        }
        const int32_t dx = d == 1 ? 1 : d == 3 ? -1 : 0, dy = d == 2 ? 1 : d == 0 ? -1 : 0;
        const int32_t nb2 = Block(board_.Tile(board_.X(t) + dx, board_.Y(t) + dy));
        frontier[nb2].push_back(t);
        ++unseen[nb2];   // an edge never seen is unseen ground too (a mirrored tile can still hide its edges)
      }
    if (m.seen_round < 0) { ++unseen[b]; continue; }
    // a live bed: one that grows a pearl within kLiveBed rounds of now (or holds one); a slow bed
    // (countdowns in the hundreds) is no field
    if (m.countdown >= 0 && (m.pearl || m.countdown - (round_ - m.seen_round) <= kLiveBed)) {
      ++beds[b];
      bed_seen[b] = std::max(bed_seen[b], m.seen_round);
      if (!occ(t)) bed_tiles[b].push_back(t);
    }
  }
  for (auto& f : frontier) {
    std::sort(f.begin(), f.end());
    f.erase(std::unique(f.begin(), f.end()), f.end());
  }
  // our own block's FIELD report (sent by FieldWord)
  {
    const int32_t b = Block(head_);
    FieldInfo& f = fields_[b];
    f.tile = bed_tiles[b].empty() ? head_ : bed_tiles[b].front();
    f.beds = beds[b];
    f.ours = ours_in[b];
    f.theirs = 0;
    for (const int32_t e : enemy_now) f.theirs += Block(e) == b;
    f.round = round_;
    int32_t due = 63;
    for (const int32_t t : bed_tiles[b]) due = std::min(due, board_.at(t).pearl ? 0 : due0[t]);
    f.due = due;
  }

  // per block, the reachable tile seen longest ago (nearest on ties)
  std::vector<int32_t> stale_tile(nb, -1);
  for (int32_t t = 0; t < n; ++t) {
    const TileMemory& m = board_.at(t);
    if (m.seen_round < 0 || paths.dist[t] <= 0 || occ(t) || Banned(t)) continue;
    const int32_t b = Block(t), c = stale_tile[b];
    if (c < 0 || m.seen_round < board_.at(c).seen_round || (m.seen_round == board_.at(c).seen_round && paths.dist[t] < paths.dist[c]))
      stale_tile[b] = t;
  }
  // the middle prior
  const int32_t mid = Middle();
  const double quarter = std::max(1.0, (board_.width() + board_.height()) / 4.0);
  const int32_t nbx = (board_.width() + kJobBlock - 1) / kJobBlock;
  auto block_centre = [&](int32_t b) {
    const int32_t x0 = (b % nbx) * kJobBlock, y0 = (b / nbx) * kJobBlock;
    return board_.Tile(std::min(x0 + kJobBlock / 2, board_.width() - 1), std::min(y0 + kJobBlock / 2, board_.height() - 1));
  };
  // a block the team knows is empty: mostly seen with < 2 beds (ours, or a fresher FIELD report)
  auto empty_block = [&](int32_t b) {
    if (unseen[b] * 4 < btiles[b] && beds[b] < 2) return true;
    if (const auto f = fields_.find(b); f != fields_.end() && f->second.round > bed_seen[b] && f->second.beds < 2 && unseen[b] * 2 < btiles[b])
      return true;
    return false;
  };
  auto held = [&](int32_t b) { return theirs_in[b] >= ours_in[b] + 2; };

  // each enemy head in view claims its p_.enemy_claims nearest food tiles (ties included), with its
  // arrival round there; we leave those it reaches first
  std::vector<int32_t> enemy_claim(n, -1);
  for (const int32_t e : enemy_now) {
    std::vector<std::pair<int32_t, int32_t>> near;   // (torus dist, tile)
    for (const int32_t t : food) {
      const int32_t d = Torus(e, t);
      if (d <= 8) near.push_back({d, t});
    }
    std::sort(near.begin(), near.end());
    int32_t cut = -1;
    for (size_t k = 0; k < near.size(); ++k) {
      if (static_cast<int32_t>(k) >= std::max(1, p_.enemy_claims) && near[k].first > cut) break;
      cut = near[k].first;
      const int32_t t = near[k].second, r = BedReady(near[k].first, due0[t], 0.0);
      if (enemy_claim[t] < 0 || r < enemy_claim[t]) enemy_claim[t] = r;
    }
  }
  // candidate (participant, job) pairs
  struct Pair { double u; int32_t part, key, kind, target, t; };
  std::vector<Pair> pairs;
  auto keep = [&](size_t i, int32_t key) {
    if (i == 0) return job_key_ == key ? kJobKeep : 1.0;
    const auto it = heard_key.find(parts[i].id & 1023);
    return it != heard_key.end() && it->second == key ? kJobKeep : 1.0;
  };
  const double ws = ScoutWeight(round_);
  for (size_t i = 0; i < parts.size(); ++i) {
    // EAT
    for (const int32_t t : food) {
      const int32_t d = dist_of(i, t, false);
      if (d <= 0) continue;
      if (i == 0 && Banned(t)) continue;
      // an ally is scheduled within its horizon; we take far food too (corpses, lone pearls), as
      // nobody nearer is known to want it
      // pearls at any distance for us (corpses, lone pearls: nobody nearer is known to want them);
      // beds only when ripe within the horizon (a bed due in 1000 rounds is no food)
      const int32_t ready = BedReady(d, due0[t], 0.0);
      if (ready > kJobHorizon && (i != 0 || due0[t] > 0)) continue;
      // an enemy head eats one pearl at a time: it takes only its nearest few (the parent's g15-6)
      if (enemy_claim[t] >= 0 && enemy_claim[t] < ready) continue;
      const int32_t key = (kJobEat << 20) | t;
      const int32_t cost = BedReady(d, due0[t], p_.wait_factor);   // waiting charged as the parent did
      // food in a field is worth more than a lone pearl (the parent's cluster bonus, late-surge-17):
      // after eating it we are next to more
      double v = base[t];
#ifndef JOB_NOCLUSTER
      if (p_.cluster_bonus > 0) {
        double near = 0;
        const int32_t R = p_.cluster_radius, x = board_.X(t), y = board_.Y(t);
        for (int32_t dy = -R; dy <= R; ++dy)
          for (int32_t dx = -R + std::abs(dy); dx <= R - std::abs(dy); ++dx) {
            if (dx == 0 && dy == 0) continue;
            const int32_t m = board_.Tile(x + dx, y + dy);
            if (base[m] <= 0) continue;
            near += base[m] * (cost + 1.0) / (BedReady(d + std::abs(dx) + std::abs(dy), due0[m], p_.wait_factor) + 1.0);
          }
        v += p_.cluster_bonus * near;
      }
#endif
      pairs.push_back({v / (cost + 1.0) * keep(i, key), int32_t(i), key, kJobEat, t, ready});
    }
    // FIELD / CONTEST / SCOUT by block
    for (int32_t b = 0; b < nb; ++b) {
      if (JOB_FIELD && beds[b] >= 2 && !bed_tiles[b].empty() && !held(b) && !empty_block(b)) {
        // T: the soonest a bed of the field is ripe for us, waiting charged as the parent did
        int32_t best = -1, bd = 1 << 20;
        for (const int32_t t : bed_tiles[b]) {
          const int32_t d = dist_of(i, t, true);
          if (d < 0) continue;
          const int32_t r = base[t] > 0 ? BedReady(d, due0[t], p_.wait_factor) : d + 2 * kJobHorizon;
          if (r < bd) bd = r, best = t;
        }
        if (best >= 0 && (JOB_CONTEST || theirs_in[b] == 0)) {
          const int kind = theirs_in[b] > 0 ? kJobContest : kJobField;
          const double v = (0.4 + 0.1 * std::min(beds[b], 6)) * (kind == kJobContest ? 1.3 : 1.0);
          const int32_t key = (kind << 20) | b;
          pairs.push_back({v / (bd + 1.0) * keep(i, key), int32_t(i), key, kind, best, bd});
        }
      }
      if (unseen[b] > 0 && !frontier[b].empty() && !(i == 0 && scout_ban_.count(b) && scout_ban_[b] > round_)) {
        int32_t best = -1, bd = 1 << 20;
        for (const int32_t t : frontier[b]) {
          const int32_t d = dist_of(i, t, true);
          if (d >= 0 && d < bd) bd = d, best = t;
        }
        if (best >= 0) {
          double m = std::max(0.0, 1.0 - Torus(block_centre(b), mid) / quarter);
          if (m > 0 && (empty_block(b) || held(b))) {
#ifdef JOB_DBG
            if (i == 0) ++(held(b) ? g_job_cut_held : g_job_cut_empty);
#endif
            m = 0;
          }
          const double v = ws * std::min(1.0, unseen[b] / kScoutFull) * (1.0 + 0.5 * m);
          const int32_t key = (kJobScout << 20) | b;
          pairs.push_back({v / (bd + 1.0) * keep(i, key), int32_t(i), key, kJobScout, best, bd});
        }
      }
      // STALE(b): ground we reach but haven't looked at for a while: food may have grown there, and
      // a worker on it keeps the block ours (the parent's crowded patrol, as a job with capacity 1)
      if (stale_tile[b] >= 0 && round_ - board_.at(stale_tile[b]).seen_round >= kPatrolAge) {
        const int32_t d = dist_of(i, stale_tile[b], true);
        if (d > 0) {
          const double v = JOB_PATROLW * std::min(1.0, (round_ - board_.at(stale_tile[b]).seen_round) / double(kStaleAge));
          const int32_t key = (kJobStale << 20) | b;
          pairs.push_back({v / (d + 1.0) * keep(i, key), int32_t(i), key, kJobStale, stale_tile[b], d});
        }
      }
    }
  }
  for (int k = 0; k < 6; ++k) dbg_pairs_[k] = 0;
  for (const Pair& p : pairs) if (p.part == 0) ++dbg_pairs_[p.kind];
  dbg_ban_ = 0; dbg_fr_ = 0;
  for (int32_t b = 0; b < nb; ++b) { dbg_ban_ += scout_ban_.count(b) && scout_ban_[b] > round_; dbg_fr_ += int(frontier[b].size()); }
  // our own candidates that end in a dead end not worth entering are dropped (the parent's trap test)
  const int32_t need = RoomNeeded();
  const bool no_trap = (p_.cap_safety && length_ >= 4 && !CanCountOnSplit()) ||
                       (round_ >= p_.no_trap_from_round && length_ >= p_.no_trap_min_length);
  auto open = [&](int32_t t) { return !Occupied(t); };
  struct TrapInfo { bool ok, trap, grow; };
  std::unordered_map<int32_t, TrapInfo> trap_of;   // target -> (allowed, a dead end, entered to grow)
  bool grow_last = false;
  auto dead_end = [&](int32_t tile, bool* trap) {
    const auto it = trap_of.find(tile);
    if (it != trap_of.end()) { *trap = it->second.trap; grow_last = it->second.grow; return !it->second.ok; }
    std::vector<int32_t> pocket;
    bool ok = true, tr = false, grow = false;
    if (RoomAround(board_, tile, open, need, &pocket) < need) {
      tr = true;
      if (no_trap) ok = false;
      else {
        // the parent's pocket test (ChooseGoal): its food less trap_cost; a 2-3 long dragon may
        // enter a hot pocket whose pearls grow it to 4 (it splits out at the tip: corridor farming)
        double gain = 0;
        int32_t pearls = 0, hot = 0;
        for (const int32_t t : pocket) {
          int32_t ready;
          const double v = TileValue(t, paths.dist[t] < 0 ? paths.dist[tile] : paths.dist[t], &ready);
          gain += v;
          if (v >= 0.5) ++pearls;
          if (p_.hot_farm && hot_[t] && v > 0) ++hot;
        }
        gain += hot * p_.hot_pocket_bonus;
        grow = hot > 0 && length_ < 4 && length_ + pearls >= 4 && FreeSlots() >= 1;
        ok = gain - p_.trap_cost > 0;
      }
    }
    trap_of[tile] = {ok, tr, grow};
    *trap = tr;
    grow_last = grow;
    return !ok;
  };
  std::sort(pairs.begin(), pairs.end(), [&](const Pair& a, const Pair& b) {
    if (a.u != b.u) return a.u > b.u;
    const int32_t ia = parts[a.part].id, ib = parts[b.part].id;
    return std::tie(ia, a.key) < std::tie(ib, b.key);
  });
  auto capacity = [&](const Pair& p) {
    const int32_t b = p.kind == kJobEat ? -1 : (p.key & 0xFFFFF);
    switch (p.kind) {
      case kJobField: return (beds[b] + 1) / 2;
      case kJobContest: return theirs_in[b] + 1;
      case kJobScout: return std::clamp(unseen[b] / 16, 1, 3);   // a big unseen block takes up to 3
      default: return 1;
    }
  };
  std::vector<int32_t> job_of(parts.size(), -1);   // index into pairs
  size_t done = 0;
  int checks = 0;
  for (size_t k = 0; k < pairs.size() && done < parts.size(); ++k) {
    const Pair& p = pairs[k];
    if (job_of[p.part] >= 0 || used[p.key] >= capacity(p)) continue;
    if (p.part == 0 && p.kind != kJobScout && checks < 12) {
      bool tr;
      ++checks;
      if (dead_end(p.target, &tr)) continue;
    }
    job_of[p.part] = int32_t(k);
    ++used[p.key];
    ++done;
  }
  // nothing left for us within capacity: rather than idle, share our best job (the parent's every
  // dragon had a goal; idling cost a third of the r100 economy in the first local runs)
  if (job_of[0] < 0)
    for (size_t k = 0; k < pairs.size(); ++k) {
      const Pair& p = pairs[k];
      if (p.part != 0) continue;
      if (p.kind != kJobScout) {
        bool tr;
        if (dead_end(p.target, &tr)) continue;
      }
      job_of[0] = int32_t(k);
#ifdef JOB_DBG
      ++g_job_overflow;
#endif
      break;
    }
  Goal g;
  if (job_of[0] >= 0) {
    const Pair& p = pairs[job_of[0]];
    int32_t target = p.target;
    if (p.kind == kJobField || p.kind == kJobContest) {
      // in the field: the bed soonest ready for us that no EAT job and no earlier field worker took
      const int32_t b = p.key & 0xFFFFF;
      std::vector<uint8_t> taken(n, 0);
      for (size_t i = 0; i < parts.size(); ++i)
        if (job_of[i] >= 0 && pairs[job_of[i]].kind == kJobEat) taken[pairs[job_of[i]].target] = 1;
      std::vector<std::pair<int32_t, size_t>> order;   // field workers in assignment order
      for (size_t i = 0; i < parts.size(); ++i)
        if (job_of[i] >= 0 && pairs[job_of[i]].key == p.key) order.push_back({job_of[i], i});
      std::sort(order.begin(), order.end());
      for (const auto& [k, i] : order) {
        int32_t best = -1, br = 1 << 20;
        for (const int32_t t : bed_tiles[b]) {
          if (taken[t]) continue;
          const int32_t d = dist_of(i, t, true);
          if (d <= 0 && !(d == 0 && i != 0)) continue;
          const int32_t r = base[t] > 0 ? BedReady(d, due0[t], p_.wait_factor) : d + 40;
          if (r < br) br = r, best = t;
        }
        if (best < 0) continue;
        taken[best] = 1;
        if (i == 0) target = best;
      }
    }
    bool trap = false;
    if (target >= 0 && paths.dist[target] > 0 && !dead_end(target, &trap)) {
      g = Goal{target, trap, grow_last};
      job_kind_ = p.kind;
      job_key_ = p.key;
      job_t_ = p.t;
    } else if (target == head_ || (target >= 0 && paths.dist[target] == 0)) {
      g = Goal{};
    }
#ifdef JOB_DBG
    if (p.kind == kJobScout) {
      ++g_job_scout_turns;
      const int32_t b = p.key & 0xFFFFF;
      if (Torus(block_centre(b), mid) < quarter) ++g_job_scout_mid;
      if (beds[b] < 2 && unseen[b] * 4 < btiles[b]) ++g_job_scout_empty;
    }
#endif
  }
  // a scout that sees nothing new for kScoutStall rounds gives the block up
  if (g.tile >= 0 && job_kind_ == kJobScout) {
    if (scout_key_since_ < 0 || job_key_ != scout_key_since_) scout_key_since_ = job_key_, seen_grow_round_ = std::max(seen_grow_round_, round_);
    if (round_ - seen_grow_round_ >= kScoutStall) {
      scout_ban_[job_key_ & 0xFFFFF] = round_ + kScoutBan;
      seen_grow_round_ = round_;
#ifdef JOB_DBG
      ++g_job_giveup;
#endif
    }
  } else {
    scout_key_since_ = -1;
  }
  if (g.tile < 0) {
    // fallback: the reachable tile longest unseen (kStaleAge+), else no goal (a safe wait)
    double top = 0;
    for (int32_t t = 0; t < n; ++t) {
      const int32_t d = paths.dist[t];
      if (d <= 0 || occ(t) || Banned(t)) continue;
      const int32_t age = round_ - board_.at(t).seen_round;
      if (age < kStaleAge) continue;
      const double s = age / (d + 4.0);
      if (s > top) top = s, g = Goal{t, false};
    }
    if (g.tile >= 0) {
      job_kind_ = kJobStale;
      job_key_ = (kJobStale << 20) | Block(g.tile);
      job_t_ = paths.dist[g.tile];
    }
  }
  if (g.tile >= 0) {
    job_now_ = true;
    job_target_ = g.tile;
    job_dist_ = paths.dist[g.tile];
    job_first_ = paths.first[g.tile];
#ifdef JOB_DBG
    if (job_kind_ == kJobEat)
      for (const auto& [id, c] : job_heard_)
        if (round_ - c.round <= 1 && c.key == job_key_) ++g_job_double;
    if (job_kind_ == kJobEat) ++g_job_eat_turns;
#endif
  } else {
    job_kind_ = 0;
    job_key_ = -1;
    job_target_ = -1;
  }
  return g;
}

}  // namespace gm2
