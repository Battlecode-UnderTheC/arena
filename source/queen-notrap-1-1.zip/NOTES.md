# queen-notrap-1

Parent: `queen-trade-1` (the outnumbered-gate fix, itself drafted at `queen-trade-1-1` and net-
neutral vs `queen-3` on the full arena suite). One flag flipped, nothing else.

## The analysis behind it

Decoded 55 local replays (queen-3/queen-2 self-play plus a queen-3-vs-gst-giant-2 set, across
arena/Colosseum/default_small/devil) with a capnp decoder that tracks team-per-id from split
events and pairs same-round head-to-head deaths by matching last-known position (not just "any
other death that round", which misattributes when multiple fights overlap in one round).

- **100% of games had a queen die; 82% had both.** Median round of death: 24. 84% of queen
  deaths happen before round 50 -- purely an opening/early-midgame problem.
- **Queen deaths are never friendly fire.** 0 of 68 identified kills were by an ally; 100%
  enemy. General head-to-head friendly fire (all dragons) is 1.7% -- a real but minor background
  rate, irrelevant to the queen specifically.
- **100% (68/68) of head-to-head queen deaths have the queen acting first in the fatal round.**
  Dragon ids 0/1 are always the two queens, the lowest ids in the game, so the queen moves before
  almost every split child that will ever exist. The engine lets later actors in a round see what
  earlier ones already did ("each sees what the ones before it left") -- so the queen commits to a
  tile blind, and a higher-id enemy worker, acting later the same round, reacts to the queen's
  *current* position with strictly fresher information than the queen had when it moved there.
  Every reactive defense (margin tie-breaks, hard vetoes, proactive flee, a parking/anchor
  restriction -- five variants, all tried and reverted this investigation) loses that one-round
  information race regardless of tuning, because it's structural, not a decision-quality gap.
- **The cause of death is not uniform across maps -- devil is a different failure mode entirely:**

  | map | queen deaths | breakdown |
  |---|---|---|
  | arena | 29 | 28 hitHeadToHead, 1 noValidAction |
  | colosseum | 16 | 15 hitHeadToHead, 1 hitOtherBody |
  | default_small | 17 | 15 hitHeadToHead, 2 noValidAction |
  | arena vs gst-giant-2 | 18 | 14 hitHeadToHead, 3 noValidAction, 1 hitOtherBody |
  | **devil** | 20 | **20 noValidAction, 0 hitHeadToHead** |

  On devil, every single queen death in the sample was the queen boxed into a dead end with no
  legal move -- not combat at all. `kQueenNoTrap` ("the queen never takes a dead-end goal or
  step") exists in the codebase for exactly this, but had only ever been tested bundled with
  `kQueenReach` (which measurably hurts on its own: a broad distance-based heuristic that marks
  almost the whole 7x7 window "unsafe" once any decent-length enemy is visible, since its reach
  can exceed the window's own radius). Isolating `kQueenNoTrap` matters because, unlike
  `kQueenReach`, it reuses the same `EscapeLevel`/`RoomAround` dead-end detection every dragon on
  the team already relies on -- not a new heuristic that can mis-fire broadly, just an exception
  removed for one dragon.

## The change

`strategy.hpp`: `kQueenNoTrap = false` -> `true`. `kQueenReach` stays `false` (it was isolated and
tested; it hurts on its own too, independent of this flag).

## Evidence

Same-seed local comparisons (`unswbc` 1.2.7 sandbox) against `queen-trade-1` with the flag
unchanged:

| map | queen-trade-1 (baseline) | queen-notrap-1 |
|---|---|---|
| arena (20 seeds) | 60% win, 18/20 queen deaths | 60% win (exact same win count), 18/20 |
| Colosseum (20 seeds) | 75% win, 14/20 queen deaths | 75% win (exact same win count), 15/20 |
| devil (20 seeds) | 55% win, 20/20 queen deaths | 55% win (exact same win count), **19/20** |

Zero measured cost on the two combat-dominant maps (win counts match baseline exactly, not just
approximately). A small, single-sample-worth improvement on devil, its target map -- needs a much
larger sample (this submission) to confirm it holds, but there's no downside risk visible in 60
games across 3 maps to justify withholding it.

## What I'd try next

- devil's 20/20 -> 19/20 is one game's worth of signal; re-check once this has played enough
  arena games to have a real sample size on that specific map.
- The structural "queen always acts first" finding suggests the productive next angle isn't
  further *queen* behavior changes (five attempts at that have now failed or landed neutral) but
  possibly denying attackers the fresh information advantage some other way -- e.g. whether
  sonar-based misdirection or decoy signals are worth exploring, since the problem isn't the
  queen's decision quality, it's an information deficit baked into dragon id ordering.
