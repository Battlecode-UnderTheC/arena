# queen-ring17-explore-1

Parent: queen-ring17-hunt-3-1. Ported from ring-plus-9 (current #1): before round 150 a worker values unexplored
ground more the longer it has gone without eating (up to 2x) and more when the team has seen less of the map
(up to 1x). Hypothesis: faster early pearl finding gives the bigger round-100 swarm that wins have.
