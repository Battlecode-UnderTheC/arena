# queen-trade-1

Parent: `queen-3` (fetched from the arena with `tokenz get queen-3`, not a tracked variant
in this repo). One-line change, see below.

## The weakness

Read `tokenz report queen-3`'s `worst_losses` and decoded the replays (`.replay` is capnp,
packed; pycapnp on Windows segfaults on `replay.capnp` because of the `Cxx` c++.capnp
annotation import and on any lazy field touched after the file handle closes -- strip the
`Cxx` lines and keep the file open for the whole read to work around both).

Every one of queen-3's five worst recorded losses (games 921, 923, 938, 944, 960; vs
queen-2 and gst-giant-2, on arena/Colosseum/default_small) ends in `teamEliminated` with the
losing side's death list *entirely* `hitHeadToHead`, arriving in simultaneous pairs round
after round (e.g. four deaths in one round = two mutual head-to-head kills). The queen
itself (dragon id 0 or 1) dies to `hitHeadToHead` in 4 of the 5 games. The team that loses
is not out-fought piece for piece -- each head-to-head is a 1-for-1 trade by the engine's
own rule -- it simply runs out of dragons first because it had fewer to begin with, and kept
trading anyway.

The cause is `WorthTrading` in `strategy.cpp`: the queen-mode special case
(`enemy_id <= 1 && ... their queen dead decides the game: always worth one of ours`)
returns `true` unconditionally, with no outnumbered check -- unlike every other branch of
the same function, which the header comment itself describes as trading only "when the
numbers favour us" and which has an explicit comment three lines below:
`// trades are one for one: when they have more dragons, even trades walk us to elimination`.
The queen-kill case was carved out of that discipline. A worker throws itself at the enemy
queen (or anything that ends up adjacent to it) regardless of whether we are already
losing the war of attrition, which is exactly the scenario the rest of the function exists
to avoid.

I also tried enabling `kQueenNoTrap`/`kQueenReach` (the queen's own dead-end/lunge-range
avoidance, both `false` in queen-3) on the theory that the queen's own head-to-head deaths
were a lunge the queen failed to dodge. Measured on 10 seeds vs queen-2 on arena this made
things *worse* (50% -> 10% alone, 50% -> 20% combined with the fix below) -- the extra
caution costs the queen (who is also the leader doing the early gather/split economy)
enough tempo/positioning that it loses more than it saves. Reverted; left both at `false`,
unchanged from queen-3.

## The change

`strategy.cpp`, `WorthTrading`: gate the unconditional queen-kill trade behind the same
`units_ >= EnemiesSeen()` (or `p_.outnumbered_factor <= 0`) guard the ordinary trade case
already uses two branches down. One condition added, nothing else touched.

## Evidence

`unswbc` upgraded 1.2.2 -> 1.2.7 locally (1.2.2 predates the 2026-10-01 queen rules).
Matches run with `unswbc run <map> <a> <b> --sandbox --seed N --no-replay` (the real judge
engine, not this repo's port), alternating sides across seeds, queen-trade-1 vs the
unmodified `queen-3`/`queen-2` binaries fetched from the arena. queen-2 and queen-3 gave
*identical* win/loss tallies against queen-trade-1 on every map tried (down to the digit),
so they are behaviourally the same opponent for this test; only queen-2's numbers are
listed below as the right-hand number is queen-3's arena-reported baseline for comparison.

| map | queen-3's arena win rate (480-game report) | queen-trade-1 (20 seeds, both sides) |
|---|---|---|
| official/arena | 50% | 60% (12/20) |
| official/Colosseum | 60% | 75% (15/20) |
| official/default_small | 40% | 55% (11/20) |
| official/devil | 40% | 55% (11/20) |
| server/queen_of_spades | 35% | 50% (10/20) |

Every map tested improves, by 10-15 points, with no regressions found. These are exactly
the maps queen-3 was worst on (its five lowest-scoring maps in the arena report, `islands`
and the `rotating/wg*` worldgen maps excepted -- not present in this checkout to test
against locally).

## What I'd try next

- The attrition-loss pattern wasn't limited to the queen-kill case; it's worth checking
  whether the ordinary `p_.outnumbered_factor` threshold itself is tuned tightly enough,
  now that sprints are cheaper (ceil(L/4) free steps, 1.2.3) and head-to-heads may be
  easier to force.
- `islands` and the worldgen rotating maps (queen-3's two worst in the arena report, 25-30%)
  aren't in this checkout; worth testing against once available, since small/choked maps
  seem to be where this failure mode bites hardest.
- Local validation only; arena ratings (Bradley-Terry vs the full opponent pool, holdout
  maps) are the real test before this should be considered for promotion.
