// explorer-2's copy of shared/lib/board_memory: what one dragon knows of the board, from
// its own observations and from what its team tells it over sonar (Merge, Known).
#pragma once

#include <algorithm>
#include <cstdint>
#include <unordered_map>
#include <vector>

#include "observation.hpp"

namespace ex2 {

inline constexpr int32_t kBlocked = -1;   // Step(): kelp
inline constexpr int32_t kUnknown = -2;   // Step(): an edge or a portal's far end never seen

struct TileMemory {
  int32_t seen_round = -1;                // last round in view (-1 never)
  bool pearl = false;                     // a pearl there when last seen
  int32_t countdown = -1;                 // its bed's countdown when last seen (-1 no bed)
  int32_t occupant = -1;                  // dragon id on it when last seen (-1 none)
  uint8_t occupant_team = 0;
  bool occupant_head = false;
  int32_t gap_n = 0;                      // respawn gaps seen drawn at this bed (a countdown that jumped)
  int32_t gap_sum = 0;                    // ... and their sum
  int32_t gap_min = 1 << 20;              // the smallest gap seen drawn
  int32_t gap_max = 0;                    // the largest countdown ever displayed (a gap is at least that)
};

class TeamMemory {
 public:
  TeamMemory(int32_t width, int32_t height);

  // Folds in one observation: the 7x7 window's tiles, edges and dragons.
  void Update(const rl::Observation& o);

  int32_t width() const { return w_; }
  int32_t height() const { return h_; }
  int32_t size() const { return w_ * h_; }
  int32_t Tile(int32_t x, int32_t y) const;   // wrapped (the board is a torus)
  int32_t X(int32_t t) const { return t % w_; }
  int32_t Y(int32_t t) const { return t / w_; }
  const TileMemory& at(int32_t t) const { return tiles_[t]; }

  // The tile a step from `t` towards `dir` (0 N, 1 E, 2 S, 3 W) lands on, as far as
  // this dragon knows: through portals it has seen both ends of; kBlocked for kelp;
  // kUnknown for an edge it never saw or a portal whose far end it hasn't found.
  int32_t Step(int32_t t, int dir) const;

  // The edge codes on t's north and west sides (-1 empty, -2 kelp, a portal id), and
  // whether both are known.
  int32_t North(int32_t t) const { return north_[t]; }
  int32_t West(int32_t t) const { return west_[t]; }
  bool EdgesKnown(int32_t t) const { return north_[t] != kEdgeUnseen && west_[t] != kEdgeUnseen; }
  // What another dragon reported of tile (x, y): its north and west edges, and as of round
  // `seen` its bed's next pearl round (-1: no bed) and whether a pearl lay there. Newer
  // reports replace older knowledge; edges never change.
  void Merge(int32_t x, int32_t y, int32_t north, int32_t west, int32_t next_pearl, bool pearl, int32_t seen);

  // The bed's mean respawn gap. The engine draws every gap uniformly from the bed's [min, max], so
  // from the gaps seen drawn (their mean, and the smallest as min) and the largest countdown
  // ever displayed (a lower bound on max) we take the larger of the sample mean and (min + max) / 2:
  // a single short draw on a bed that can wait 600 doesn't make it a farm. -1: never seen to pop
  // (beds differ: a gap-1 bed's neighbour may wait 600).
  double MeanGap(int32_t t) const {
    const TileMemory& m = tiles_[t];
    if (!m.gap_n) return -1;
    return std::max(static_cast<double>(m.gap_sum) / m.gap_n, (std::min(m.gap_min, m.gap_max) + m.gap_max) / 2.0);
  }
  // Another dragon's tally for the bed at (x, y): n gaps seen with this mean, smallest and largest
  // countdown seen; the count is kept if it is larger than ours, the extremes always.
  void MergeGap(int32_t x, int32_t y, int32_t n, int32_t mean, int32_t lo, int32_t hi) {
    if (x < 0 || x >= w_ || y < 0 || y >= h_) return;
    TileMemory& m = tiles_[Tile(x, y)];
    if (n > m.gap_n) m.gap_n = n, m.gap_sum = mean * n;
    m.gap_min = std::min(m.gap_min, lo);
    m.gap_max = std::max(m.gap_max, hi);
  }
  int32_t pool_n() const { return pool_n_; }

  // Seen in the current round (so its occupant is exact, not a stale memory).
  bool Current(int32_t t) const { return tiles_[t].seen_round == round_; }
  int32_t round() const { return round_; }

 private:
  static constexpr int32_t kEdgeUnseen = INT32_MIN;
  struct EdgeRef {
    bool horizontal;                      // north side of (x, y); else west side of (x, y)
    int32_t x, y;
    bool operator==(const EdgeRef&) const = default;
  };
  int32_t SideCode(int32_t t, int dir) const;          // the edge on that side of t
  void Note(bool horizontal, int32_t x, int32_t y, int32_t code);
  int32_t Exit(const EdgeRef& partner, int dir) const; // the tile past a portal's far end

  int32_t w_, h_, round_ = -1;
  int64_t pool_n_ = 0, pool_sum_ = 0;
  std::vector<TileMemory> tiles_;
  std::vector<int32_t> north_, west_;                  // edge codes: -1 empty, -2 kelp, portal id
  std::unordered_map<int32_t, std::vector<EdgeRef>> portal_ends_;
};

}  // namespace ex2
