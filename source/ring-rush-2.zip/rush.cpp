// g39-rush2 (ring-rush-2): contest the shared food we have OBSERVED, and explore fast when there
// is none. No board-centre target, no map-shape assumption.
//
// Server-r13: the opponent holds contested bed clusters by about r16; we arrive at r26-31 and
// stop 1-4 tiles short (every tile there is in an enemy head's reach). ring-rush-1 rushed the
// geometric centre; this version rebuilds the idea from what each dragon sees.
//
// 1. Candidates: bed/pearl clusters in this dragon's board memory: seen, or inferred by the
//    committed symmetry (sym.hpp), including beds not yet live (counted when due before we can
//    arrive plus kDueSlack).
// 2. Contested: our arrival (torus steps from our head) is no later than theirs + kParitySlack,
//    and theirs no later than ours + kSharedWindow (else the cluster is simply ours). Theirs is
//    estimated from enemy heads seen in the last kHeadFresh rounds, and from the enemy spawn:
//    the mirror of our own spawn under the committed symmetry. Neither known: nothing contested.
// 3. Rushers (the two lowest-id non-queen starters, q+2 and q+4) walk to the best contested
//    cluster (most food, then nearest) before r30 with free second steps, then hold it to r60.
//    Any worker within 7 of a contested cluster contests at local head parity (ring-rush-1).
// 4. No contested cluster: until r30 a rusher explores. With the symmetry committed it walks to
//    the torus midpoint between its spawn and the mirrored enemy spawn; before that, toward the
//    least-seen of 8 points a quarter-board away. It eats pearls within kPearlDetour on the way,
//    ends on arrival, and stops after kRushStall rounds without progress (walled spawns).
#include <algorithm>
#include <cstdio>
#include <cstring>

#include "strategy.hpp"

namespace gm2 {
using namespace strat;

namespace {
constexpr int32_t kRushUntil = 30;       // the rush (and exploration) phase ends here
constexpr int32_t kArrive = 2;           // within this many tiles of the target: arrived
constexpr int32_t kRushStall = 6;        // rounds without getting nearer before giving up
constexpr int32_t kMiddleUntil = 60;     // the hold and the parity rule end here
constexpr int32_t kMiddleRadius = 7;     // "at the contest": head within this of the cluster
constexpr int32_t kClusterRadius = 2;    // food within this of a centre counts to its cluster
constexpr double kClusterMin = 2.0;      // a cluster worth contesting
constexpr int32_t kParitySlack = 2;      // we may arrive this much after them and still contest
constexpr int32_t kSharedWindow = 10;    // they arrive more than this after us: it's just ours
constexpr int32_t kDueSlack = 15;        // a bed due within our travel + this counts as food
constexpr int32_t kHeadFresh = 6;        // enemy heads seen this recently estimate their arrival
constexpr int32_t kExploreMin = 5;       // an exploration target nearer than this isn't worth it
constexpr int32_t kPearlDetour = 4;      // an explorer eats pearls this close on the way
constexpr int32_t kRetarget = 3;         // a new target this near the old keeps the stall clock
}  // namespace

int32_t StrategyAgent::Torus(int32_t a, int32_t b) const {
  const int32_t dx = std::abs(board_.X(a) - board_.X(b)), dy = std::abs(board_.Y(a) - board_.Y(b));
  return std::min(dx, board_.width() - dx) + std::min(dy, board_.height() - dy);
}

bool StrategyAgent::InMiddle() const {
  if (IsQueen() || round_ >= kMiddleUntil) return false;
  if (contest_ >= 0 && Torus(head_, contest_) <= kMiddleRadius) return true;
  return rush_state_ == 2 && rush_target_ >= 0 && Torus(head_, rush_target_) <= kMiddleRadius;
}

void StrategyAgent::HeadsNear(int32_t at, int32_t r, int32_t* ours, int32_t* theirs) const {
  *ours = 1;   // ourselves
  *theirs = 0;
  for (const auto& [id, w] : seen_) {
    if (id == spawn_.id || w.round != round_ || w.head < 0 || Torus(w.head, at) > r) continue;
    if (w.team == spawn_.team) ++*ours;
    else ++*theirs;
  }
}

// the mirror of our spawn under the committed symmetry: an enemy spawn (map dragons are placed
// symmetrically, the two teams on mirrored tiles); -1 before commitment or without a spawn
int32_t StrategyAgent::EnemySpawn() const {
  if (spawn_tile_ < 0) return -1;
  const uint8_t s = sym_.Usable();
  if (s != 1 && s != 2 && s != 4) return -1;
  const int32_t x = board_.X(spawn_tile_), y = board_.Y(spawn_tile_), w = board_.width(), h = board_.height();
  const int32_t m = board_.Tile(s == 1 ? x : w - 1 - x, s == 2 ? y : h - 1 - y);
  return m == spawn_tile_ ? -1 : m;
}

// the best contested food cluster this dragon knows of, or -1
void StrategyAgent::UpdateContest() {
  contest_ = -1;
  if (round_ >= kMiddleUntil) return;
  const int32_t es = EnemySpawn();
  std::vector<std::pair<int32_t, int32_t>> heads;   // enemy head tile, round seen
  for (const auto& [id, w] : seen_)
    if (w.team != spawn_.team && w.head >= 0 && round_ - w.round <= kHeadFresh) heads.push_back({w.head, w.round});
  if (es < 0 && heads.empty()) return;
  std::vector<int32_t> food;
  for (int32_t t = 0; t < board_.size(); ++t) {
    const TileMemory& m = board_.at(t);
    if (m.seen_round < 0) continue;
    if (m.pearl) {
      food.push_back(t);
      continue;
    }
    if (m.countdown < 0) continue;
    const int32_t due = m.countdown - (round_ - m.seen_round);
    if (due <= Torus(head_, t) + kDueSlack) food.push_back(t);
  }
  if (food.size() < 2) return;
  int32_t best = -1, best_ours = 0;
  [[maybe_unused]] int32_t best_theirs = 0;
  double best_score = kClusterMin - 1e-9;
  constexpr int32_t kFar = 1 << 20;
  for (const int32_t f : food) {
    const int32_t ours = Torus(head_, f);
    int32_t theirs = es >= 0 ? Torus(es, f) - round_ : kFar;
    for (const auto& [h, r] : heads) theirs = std::min(theirs, Torus(h, f) - (round_ - r));
    if (ours > theirs + kParitySlack || theirs > ours + kSharedWindow) continue;
    double s = 0;
    for (const int32_t g : food) s += Torus(f, g) <= kClusterRadius;
    if (s > best_score + 1e-9 || (best >= 0 && s > best_score - 1e-9 && ours < best_ours)) {
      best = f;
      best_score = s;
      best_ours = ours;
      best_theirs = theirs;
    }
  }
  contest_ = best;
#ifdef RUSH_TRACE
  if (best >= 0 && (contest_log_ < 0 || Torus(best, contest_log_) > kRetarget)) {
    const int32_t sp = spawn_tile_;
    std::fprintf(stderr, "CONTEST r%d id%d team%d at %d,%d score%.0f ours%d theirs%d src%s spawn %d,%d dspawn %d despawn %d\n", round_,
                 spawn_.id, spawn_.team, board_.X(best), board_.Y(best), best_score, best_ours, best_theirs, es >= 0 ? "spawn" : "head",
                 sp >= 0 ? board_.X(sp) : -1, sp >= 0 ? board_.Y(sp) : -1, sp >= 0 ? Torus(sp, best) : -1, es >= 0 ? Torus(es, best) : -1);
  }
  if (best >= 0) contest_log_ = best;
  if (best >= 0) ++contest_turns_;
#endif
}

// exploration: the torus midpoint to the mirrored enemy spawn once the symmetry is committed,
// else the least-seen of 8 points a quarter-board from our spawn (rusher k takes rank k)
int32_t StrategyAgent::ExploreTarget(bool* committed) const {
  *committed = false;
  if (spawn_tile_ < 0) return -1;
  const int32_t w = board_.width(), h = board_.height(), sx = board_.X(spawn_tile_), sy = board_.Y(spawn_tile_);
  if (const int32_t es = EnemySpawn(); es >= 0) {
    *committed = true;
    int32_t dx = board_.X(es) - sx, dy = board_.Y(es) - sy;
    if (dx > w / 2) dx -= w;
    if (dx < -w / 2) dx += w;
    if (dy > h / 2) dy -= h;
    if (dy < -h / 2) dy += h;
    const int32_t mid = board_.Tile(sx + dx / 2, sy + dy / 2);
    return Torus(spawn_tile_, mid) >= kExploreMin ? mid : -1;
  }
  static constexpr int kDir[8][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
  std::vector<std::pair<int32_t, int>> ranked;   // (unseen, -index)
  for (int k = 0; k < 8; ++k) {
    const int32_t p = board_.Tile(sx + kDir[k][0] * (w / 4), sy + kDir[k][1] * (h / 4));
    if (Torus(spawn_tile_, p) < kExploreMin) continue;
    int32_t unseen = 0;
    for (int32_t ey = -3; ey <= 3; ++ey)
      for (int32_t ex = -3 + std::abs(ey); ex <= 3 - std::abs(ey); ++ex)
        unseen += board_.at(board_.Tile(board_.X(p) + ex, board_.Y(p) + ey)).seen_round < 0;
    ranked.push_back({unseen, -k});
  }
  if (ranked.empty()) return -1;
  std::sort(ranked.rbegin(), ranked.rend());
  const size_t r = std::min<size_t>(rusher_rank_, ranked.size() - 1);
  const int k = -ranked[r].second;
  return board_.Tile(sx + kDir[k][0] * (w / 4), sy + kDir[k][1] * (h / 4));
}

void StrategyAgent::NoteSeen() {
#ifdef RUSH_TRACE
  if (round_ == 30 || round_ == 60) {
    int32_t seen = 0;
    for (int32_t t = 0; t < board_.size(); ++t) seen += board_.at(t).seen_round >= 0;
    std::fprintf(stderr, "SEEN r%d id%d team%d frac %.3f contest_turns %d\n", round_, spawn_.id, spawn_.team, double(seen) / board_.size(),
                 contest_turns_);
  }
#endif
}

void StrategyAgent::UpdateRush() {
  rush_now_ = false;
  if (round_ == born_ && leader_ && spawn_tile_ < 0) spawn_tile_ = head_;
#ifdef RUSH_OFF
  rush_state_ = 3;
  return;
#endif
  if (IsQueen()) {
    rush_state_ = 3;
    return;
  }
  UpdateContest();
  if (rush_state_ == 0) {
    rush_state_ = 3;
    const int32_t q = spawn_.id & 1;
    if (leader_ && round_ == 0 && (spawn_.id == q + 2 || spawn_.id == q + 4)) {
      rush_state_ = 1;
      rusher_rank_ = spawn_.id == q + 2 ? 0 : 1;
    }
  }
  if (rush_state_ == 2 && round_ >= kMiddleUntil) rush_state_ = 3;
  if (rush_state_ != 1) return;
  if (round_ >= kRushUntil) {
    rush_state_ = rush_cluster_ && rush_target_ >= 0 && Torus(head_, rush_target_) <= kMiddleRadius ? 2 : 3;
    return;
  }
  int32_t target = -1;
  bool cluster = false;
  if (contest_ >= 0 && (failed_tile_ < 0 || Torus(contest_, failed_tile_) > kRetarget)) {
    target = contest_;
    cluster = true;
  } else if (!explore_done_) {
    bool committed;
    if (explore_tile_ < 0 || (!explore_committed_ && EnemySpawn() >= 0)) {
      explore_tile_ = ExploreTarget(&committed);
      explore_committed_ = committed;
      if (explore_tile_ < 0) explore_done_ = true;
    }
    target = explore_tile_;
  }
  if (target < 0) return;
  if (rush_target_ < 0 || Torus(target, rush_target_) > kRetarget || cluster != rush_cluster_) rush_best_ = -1;
  rush_target_ = target;
  rush_cluster_ = cluster;
  const int32_t left = Torus(head_, target);
  if (left <= kArrive) {
    if (cluster) rush_state_ = 2;
    else explore_done_ = true;
#ifdef RUSH_TRACE
    std::fprintf(stderr, "RUSHARRIVE r%d id%d team%d %s at %d,%d\n", round_, spawn_.id, spawn_.team, cluster ? "cluster" : "explore",
                 board_.X(target), board_.Y(target));
#endif
    return;
  }
  // no step nearer the target for kRushStall rounds: the way is shut, give it up
  if (rush_best_ < 0 || left < rush_best_) {
    rush_best_ = left;
    rush_since_ = round_;
  } else if (round_ - rush_since_ >= kRushStall) {
#ifdef RUSH_TRACE
    std::fprintf(stderr, "RUSHSTALL r%d id%d team%d %s at %d,%d left %d\n", round_, spawn_.id, spawn_.team, cluster ? "cluster" : "explore",
                 board_.X(target), board_.Y(target), left);
#endif
    if (cluster) failed_tile_ = target;
    else explore_done_ = true;
    return;
  }
  rush_now_ = true;
}

// an explorer eats pearls on the way: a live pearl within kPearlDetour steps pauses the walk
bool StrategyAgent::PearlNear(const Paths& paths) const {
  for (int32_t t = 0; t < board_.size(); ++t)
    if (paths.dist[t] > 0 && paths.dist[t] <= kPearlDetour && board_.at(t).pearl && !Banned(t)) return true;
  return false;
}

// the tile to walk to: the target when known and reachable, else the known tile that minimises
// steps there plus the straight distance on to the target (from ring-rush-1)
int32_t StrategyAgent::RushGoal(const Paths& paths) const {
  const int32_t T = rush_target_;
  int32_t best = -1, best_cost = 1 << 30, best_left = 1 << 30;
  for (int32_t t = 0; t < board_.size(); ++t) {
    const int32_t d = paths.dist[t];
    if (d <= 0 || Banned(t) || Classify(t) != Cell::kFree) continue;
    const int32_t left = Torus(t, T);
    // only the frontier (a tile beside an edge never seen) or the target's own neighbourhood:
    // a known tile walled off from the target is no way there
    bool frontier = left <= kArrive;
    for (int k = 0; k < 4 && !frontier; ++k) frontier = board_.Step(t, k) == kUnknown;
    if (!frontier) continue;
    int32_t cost = d + left;
    if (cost < best_cost || (cost == best_cost && left < best_left)) {
      best = t;
      best_cost = cost;
      best_left = left;
    }
  }
  return best;
}

// a second free step along the shortest known path to the goal, when our length makes it free
// and the tile is in view, free, not exposed and roomy (from ring-rush-1)
bot::Action StrategyAgent::RushSprint(bot::Action a, int32_t goal) const {
  if (goal < 0 || (length_ + 3) / 4 < 2 || a.kind != bot::Action::kMove || a.resign || a.steps.size() != 1 ||
      std::strcmp(reason_, "toward goal") != 0)
    return a;
  const int32_t t1 = board_.Step(head_, a.steps[0]);
  if (t1 < 0 || t1 == goal) return a;
  // distances to the goal over free known tiles
  std::vector<int32_t> g(board_.size(), -1);
  std::vector<int32_t> queue{goal};
  g[goal] = 0;
  for (size_t qi = 0; qi < queue.size(); ++qi) {
    const int32_t t = queue[qi];
    if (t == t1 || g[t] >= 40) continue;
    for (int d = 0; d < 4; ++d) {
      const int32_t n = board_.Step(t, d);
      if (n < 0 || g[n] >= 0 || (n != t1 && Classify(n) != Cell::kFree)) continue;
      g[n] = g[t] + 1;
      queue.push_back(n);
    }
  }
  if (g[t1] < 2) return a;
  const int32_t need = RoomNeeded();
  auto open = [&](int32_t t) { return !Occupied(t) && !Exposed(t); };
  for (int d = 0; d < 4; ++d) {
    const int32_t t2 = board_.Step(t1, d);
    if (t2 < 0 || t2 == head_ || !board_.Current(t2) || Classify(t2) != Cell::kFree || g[t2] != g[t1] - 1) continue;
    if (Exposed(t2) || RoomAround(board_, t2, open, need) < need) continue;
    a.steps.push_back(d);
    return a;
  }
  return a;
}

}  // namespace gm2
