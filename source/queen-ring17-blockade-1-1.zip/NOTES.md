# queen-ring17-blockade-1

Parent: queen-ring17-hunt-3-1. Counter to ring-plus-9 (current #1): its queen is within 3 tiles of our units in
about 5 percent of rounds, so hunting its tile fails. Change: hunters aim at the free tile next to the enemy
queen that they reach soonest, which puts workers on the exits of its ring.
