#include "strategy.hpp"
#include <algorithm>
namespace gm2 {
#ifndef RING_UNKNOWN_PORTAL_FIX
#define RING_UNKNOWN_PORTAL_FIX 1
#endif
#ifndef RING_PATROL
#define RING_PATROL 0
#endif
uint64_t StrategyAgent::RingWord() const {
  uint64_t w = uint64_t(0xB7) << 56;
  for (int i=0;i<4;++i) w |= uint64_t(ring_[i]) << (12*i);
  return w | (uint64_t(ring_seen_ & 255) << 48);
}
bot::Action StrategyAgent::RingQueen() {
  auto free = [&](int t) { return t >= 0 && board_.Current(t) &&
    (board_.at(t).occupant < 0 || board_.at(t).occupant == spawn_.id); };
  // Only accept ordinary geometrical 2x2 rings, with no beds and two outside exits.
  if (ring_.empty() && length_ >= 4 && round_ < 100 && FreeSlots() > 1 &&
      int(body_.size()) == length_ && SplitSafe(length_ - 2))
    return Because("ring: bootstrap shorten", bot::Action::Split(length_ - 2));
  if (!RING_PATROL) return bot::Action{};
  if (ring_.empty() && length_ <= 3 && int(body_.size()) == length_) {
    for (int d=0;d<4 && ring_.empty();++d) for (int turn : {1,3}) {
      std::vector<int> r{head_}; int t=head_; bool good=true;
      for (int k=0;k<3;++k) { t=board_.Step(t,(d+turn*k)%4); if (!free(t)) {good=false;break;} r.push_back(t); }
      if (!good || board_.Step(r.back(),(d+turn*3)%4)!=head_) continue;
      auto unique=r;std::sort(unique.begin(),unique.end());if(std::adjacent_find(unique.begin(),unique.end())!=unique.end())continue;
      for (int tile:r) {
        if (board_.at(tile).countdown>=0 || board_.at(tile).pearl)good=false;
        for (int dir=0;dir<4;++dir) {
          int n=board_.Step(tile,dir);
          if(n<0)continue;
          int dx=std::abs(board_.X(n)-board_.X(tile)),dy=std::abs(board_.Y(n)-board_.Y(tile));
          if(dx+dy!=1 && std::find(r.begin(),r.end(),n)!=r.end())good=false;
        }
      }
      // Existing body must be the reverse suffix of the proposed loop.
      for(int k=1;k<length_;++k) if(body_[k]!=r[4-k])good=false;
      int exits=0;
      for(int tile:r) for(int dir=0;dir<4;++dir) {
        int n=board_.Step(tile,dir);
        if(n>=0 && std::find(r.begin(),r.end(),n)==r.end() && free(n) && board_.at(n).countdown<0)++exits;
      }
      if(good && exits>=2)ring_=r;
    }
  }
  if(ring_.empty())return bot::Action{};
  ring_seen_=round_;
  auto pos=std::find(ring_.begin(),ring_.end(),head_);
  if(pos==ring_.end()) {ring_.clear();return bot::Action{};}
  // A 4-long queen must shed; worker slots are reserved below.
  if(length_>=4 && round_<499 && FreeSlots()>0 && int(body_.size())==length_) {
    return Because("ring: shed to two",bot::Action::Split(length_-2));
  }
  int next=ring_[(pos-ring_.begin()+1)%4];
  bool safe=free(next) && !Mine(next);
  // React to current visible intruders; no assumption that they intentionally hunt queens.
  for(const auto& [id,e]:seen_) if(e.team!=spawn_.team && e.round==round_) {
    auto paths=Search(board_,e.head,[&](int t){return t==head_ || t==next || !Occupied(t);},3);
    if(paths.dist[next]>=0 && paths.dist[next]<=3)safe=false;
  }
  if(safe)for(int d=0;d<4;++d)if(board_.Step(head_,d)==next) {
    // Keep exact body memory for the base strategy's later fallback.
    body_.push_front(next); if(!board_.at(next).pearl)body_.pop_back();
    bot::Action a;a.steps={d};return Because("ring: patrol",a);
  }
  // Exit through the original queen policy when the loop is unsafe; acquire another ring later.
  ring_.clear();return bot::Action{};
}
bot::Action StrategyAgent::RingWorker(bot::Action normal,const rl::Observation& o) {
  for(uint64_t w:o.inbox)if((w>>56)==0xB7) {
    int stamp=(w>>48)&255;int age=(round_-stamp)&255;
    if(age<=12) {ring_.clear();for(int i=0;i<4;++i)ring_.push_back((w>>(12*i))&4095);ring_seen_=round_-age;}
  }
  if(round_-ring_seen_>12)ring_.clear();
  // Keep one slot for queen emergency splitting; this is per-turn observed unit count.
  if(normal.kind==bot::Action::kSplit && FreeSlots()<=1) {
    int d=FleeDirection();normal=SafeStep(d,false,false);rescue_committed_=true;
  }
  if(ring_.empty())return normal;
  auto inside=[&](int t){return std::find(ring_.begin(),ring_.end(),t)!=ring_.end();};
  // A new child entirely inside the announced loop frees its body immediately.
  if(born_==round_ && !leader_ && int(body_.size())==length_ &&
     std::all_of(body_.begin(),body_.end(),inside)) {
    rescue_committed_=true;return Because("ring: split child clearance",bot::Action::Resign());
  }
  std::vector<int> blocked=ring_;
  for(int t:ring_)for(int d=0;d<4;++d) {
    int n=board_.Step(t,d);if(n>=0 && board_.Current(n) && board_.at(n).countdown<0 && !inside(n))blocked.push_back(n);
  }
  auto reserved=[&](int t){return std::find(blocked.begin(),blocked.end(),t)!=blocked.end();};
  bool enters=false;int t=head_;
  if(normal.kind==bot::Action::kMove&&!normal.resign)for(int d:normal.steps){t=board_.Step(t,d);if(t<0) { if(!RING_UNKNOWN_PORTAL_FIX) enters=true; break; } if(reserved(t))enters=true;}
  if(normal.kind==bot::Action::kSplit)for(int tile:body_)if(inside(tile))enters=true;
  if(!enters)return normal;
  for(int d=0;d<4;++d) {
    int n=board_.Step(head_,d);if(n<0||reserved(n)||Classify(n)!=Cell::kFree)continue;
    std::vector<int> body(body_.begin(),body_.end());body.insert(body.begin(),n);if(!board_.at(n).pearl&&!body.empty())body.pop_back();
    if(EscapeLevel(body,EscapeCap(length_))==0)continue;
    rescue_committed_=true;bot::Action a;a.steps={d};return Because("ring: worker keep outside",a);
  }
  // Avoid sacrificing unrelated workers simply because no reserved-space detour exists.
  return normal;
}
}
