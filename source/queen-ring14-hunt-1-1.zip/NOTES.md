# queen-ring14-hunt-1

Parent: queen-ring14-portal-safe-1 (arena rank 1, queen alive at end in 74% of round-limit games).
Adds the queen-hunt from our lineage: spare workers with a fresh sighting of the enemy queen path to its
last-known tile, outnumbered guard kept except in the first 80 rounds. Hypothesis: ring14 defence keeps
our queen alive while the hunt raises enemy-queen kills.
