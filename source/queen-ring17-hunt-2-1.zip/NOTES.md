# queen-ring17-hunt-2

Parent: queen-ring17-hunt-1. Adds a guard so no dragon issues a split the engine would reject
(child or parent under 2 segments; from length <4 every split is illegal). On the arena 36 queen
deaths across 150 sampled games came from exactly this (fatal split from length 2-3).
