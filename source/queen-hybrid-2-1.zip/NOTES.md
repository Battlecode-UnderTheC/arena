# queen-hybrid-2

Parent: `queen-hybrid-1` (queen-trade-1 + a proactive hunt on the enemy queen's last-known
position, gated by the same outnumbered check `WorthTrading` uses). One change: drop that
outnumbered gate specifically during an early rush window.

## Why

Decoded 33 local replays of our hunt lineage against the arena's current top two bots
(`queen-ring14-portal-safe-1`, rank 1; `queen-guard-7`, rank 2): **100% of games had at least one
queen die, median death round 29, 71% of all queen deaths in rounds 20-49** -- before either
bot's ring/rollout defense has even fully engaged (ring-style bots have no loop protection at all
until they find and settle into one, which `ring.cpp`'s own bootstrap logic gates behind
`round < 100`). An early kill is also worth disproportionately more than a later one: it decides
the queen tiebreak outright, and both sides' economies are still small, so a failed early rush
costs little. `kHuntRushUntil = 80` drops the outnumbered guard specifically inside that window;
it stays on for the rest of the game, same discipline `queen-trade-1` already validated.

## Evidence so far

`queen-hybrid-1` already goes **20/20 against both `queen-ring14-portal-safe-1` and
`queen-guard-7` on arena** (enemy queen dies every game; ours dies 4-10/20). `queen-hybrid-2`
matches that exactly (20/20 both matchups, enemy queen 20/20, ours 5/20 and 10/20) -- the
early-rush change doesn't measurably change the outcome in these specific tests, because the
baseline hunt already hits a 100% ceiling against these two bots on this one map. That's not
nothing (it's the headline finding -- our hunt mechanism beats the arena's top two queens
outright on arena), but it means arena alone can't tell these two variants apart.

I could not get a clean comparison on a larger map (`big_empty`): `queen-guard-7`'s rollout
engine (16 simulated rollouts x 8-round horizon per candidate move, every turn, with a local
model that grows as more pearls/beds/dragons enter its radius) reproducibly stalls past 300
seconds on the same seed/side regardless of which of our variants it plays -- a cost issue in its
own bot, not something I could work around locally in reasonable time.

## What this submission is actually testing

Whether `queen-hybrid-2`'s change measurably beats its own parent (`queen-hybrid-1`) across the
arena's full map suite and opponent roster -- something neither of us could settle locally, since
arena saturates at 100% for both and other maps were impractically slow to sample. If it ties its
parent here too, that's still informative: it would mean the early-rush idea, while theoretically
sound, isn't distinguishable from the already-good baseline hunt at the margin.
