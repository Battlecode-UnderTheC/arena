// gst-explore-1: no floating-point contraction, so the native sim rounds like the wasm judge (KNOWLEDGE, g26-2).
#pragma STDC FP_CONTRACT OFF
#pragma clang fp contract(off)
// gst-search-6 = gst-search-4 (gst-merge-2 + arena-search-7's lookahead steering plain late moves)
// with gst-giant-2's rollout judge (rollout_giant2.hpp, tag variant/gst-giant-2; credit: the giant
// team) in place of gst-merge-2's older one: rollouts where the other side also lunges, a review
// of trapped actions against split escapes, a veto of steps into our own body, and a review of
// contested pearls (another head and a pearl in view).
#include <cstring>
#include <memory>

#include "plugin.hpp"
#include "rollout_giant2.hpp"
#include "strategy.hpp"

namespace gex1search {
bot::Agent* MakeSearch7(const rl::Spawn& s);
// from this round, gst's plain one-step moves take their direction from arena-search-7's
// per-dragon lookahead (search7.cpp), unless the judge overrode the move, the dragon is trapped,
// walks to an ally to feed it, or steps into a dead end it chose to farm
constexpr int kLateRound = 250;
constexpr bool kQueenLookahead = false;  // (gst-queen-2) the queen steps by the lookahead all game
constexpr bool kReviewEscape = true;    // gst's trapped actions are reviewed with split candidates
constexpr bool kReviewContest = true;   // moves with another head and a pearl in view are reviewed
// (gst-search-8) ... but not once the team consolidates: feeders and the champion keep gst's moves
constexpr int kContestStopBefore = 0;   // rounds before gst's feed round the contest review stops
}  // namespace gex1search

namespace {

class JudgedAgent : public bot::Agent {
 public:
  explicit JudgedAgent(const rl::Spawn& s) : gst_(s), judge_(s), search_(gex1search::MakeSearch7(s)) {}
  bot::Action Turn(const rl::Observation& o) override {
    judge_.Observe(o);
    bot::Action a = gst_.Turn(o);
    why_ = gst_.reason();
    const bool move = a.kind == bot::Action::kMove && !a.resign && !a.steps.empty();
    const bool feeding = std::strstr(why_, "feed") != nullptr || std::strstr(why_, "champion") != nullptr;
    const bool trapped = std::strstr(why_, "trapped") != nullptr;
    // gm2: a farmer stepping into a dead end it chose (the tip split is the plan) is not reviewed
    const bool farming = gex1::kJudgeSkipsDeadEnds && std::strstr(why_, "dead end") != nullptr;
    bool over = false;
    const bot::Action mine = a;
    const bool queen = gex1::kQueenMode && gst_.IsQueen();   // (gst-queen-1) unswbc 1.2.3
    if (gex1::kJudge) {
      if (judge_.IntoOwnBody(a)) {   // e.g. a portal exit our own body now covers
        a = judge_.Review(o, a, &over, false, false, true);
        if (over) why_ = "rollout: own-body veto";
      } else if (gex1search::kReviewEscape && trapped) {
        a = judge_.Review(o, a, &over, true);
        if (over) why_ = a.kind == bot::Action::kSplit ? "rollout: escape split" : "rollout: escape move";
      } else if (move && !feeding && !farming && !queen && judge_.EnemyHeadInView(o)) {
        a = judge_.Review(o, a, &over);
        if (over) why_ = a.steps.size() > 1 ? "rollout: lunge" : "rollout: override";
      } else if (gex1search::kReviewContest && move && !feeding && !farming && !queen &&
                 o.round < gst_.FeedFrom() - gex1search::kContestStopBefore && judge_.OtherHeadAndPearlInView(o)) {
        a = judge_.Review(o, a, &over, false, true);
        if (over) why_ = "rollout: contest";
      }
      // never take a move override whose path our own memory says is not free
      if (over && a.kind == bot::Action::kMove && !a.resign && !a.steps.empty() &&
          (!gst_.FreeStep(a.steps[0]) || (a.steps.size() > 1 && !gst_.PathFree(a.steps)))) {
        a = mine;
        over = false;
        why_ = gst_.reason();
      }
      // (gst-queen-1) the queen takes no judged lunge, and a judged step only if it is safe
      if (over && queen && a.kind == bot::Action::kMove && !a.resign &&
          (a.steps.size() != 1 || !gst_.QueenSafeStep(a.steps[0]))) {
        a = mine;
        over = false;
        why_ = gst_.reason();
      }
    }
    const bot::Action b = search_->Turn(o);   // sees every observation from turn 1
    if (o.round >= gex1search::kLateRound && !over && !feeding && !trapped && !farming && !gst_.WalkingToAlly() &&
        a.kind == bot::Action::kMove && !a.resign && a.steps.size() == 1 && b.kind == bot::Action::kMove &&
        !b.resign && b.steps.size() == 1 &&
        (!queen || (std::strcmp(search_->reason(), "search") == 0 && gst_.QueenSafeStep(b.steps[0])))) {
      a.steps = b.steps;
      why_ = "late: lookahead step";
    }
    // (gst-queen-2) the queen moves by the lookahead all game: its time-aware room test keeps a
    // long body out of the corridors where gst's room check lets it get boxed in (and a boxed-in
    // queen's trapped split leaves a 2-long stub under its id, which dies)
    if (queen && gex1search::kQueenLookahead && b.kind == bot::Action::kMove && !b.resign && b.steps.size() == 1 &&
        std::strcmp(search_->reason(), "search") == 0 && gst_.QueenSafeStep(b.steps[0]) &&
        !(a.kind == bot::Action::kSplit && std::strstr(why_, "trapped") == nullptr && std::strstr(why_, "doomed") == nullptr)) {
      a = b;
      why_ = "queen: lookahead step";
    }
    judge_.Commit(a);
    return a;
  }
  const char* reason() const override { return why_; }

 private:
  gex1::StrategyAgent gst_;
  gex1g2r::Judge judge_;
  std::unique_ptr<bot::Agent> search_;
  const char* why_ = "";
};

}  // namespace

LEAGUE_VARIANT(JudgedAgent)
