#include "strategy.hpp"
#include <algorithm>
#include <set>
namespace gm2 {
#ifndef RING_SIZE
#define RING_SIZE 6
#endif
#ifndef RING_RELEASE
#define RING_RELEASE 440
#endif
namespace {
std::vector<int> rectangle(const strat::BoardMemory& b,int x,int y,int w,int h) {
 std::vector<int> r;
 for(int i=0;i<w;++i)r.push_back(b.Tile(x+i,y));
 for(int j=1;j<h;++j)r.push_back(b.Tile(x+w-1,y+j));
 for(int i=w-2;i>=0;--i)r.push_back(b.Tile(x+i,y+h-1));
 for(int j=h-2;j>0;--j)r.push_back(b.Tile(x,y+j));
 return r;
}
}
uint64_t StrategyAgent::RingWord() const {
 int x=board_.width(),y=board_.height(),xx=0,yy=0;
 for(int t:ring_) {x=std::min(x,board_.X(t));y=std::min(y,board_.Y(t));xx=std::max(xx,board_.X(t));yy=std::max(yy,board_.Y(t));}
 return (uint64_t(0xB8)<<56)|uint64_t(x)|(uint64_t(y)<<6)|(uint64_t(xx-x+1)<<12)|(uint64_t(yy-y+1)<<14)|(uint64_t(ring_seen_&511)<<16);
}
bot::Action StrategyAgent::RingQueen() {
 if(round_>=RING_RELEASE) {ring_.clear();return bot::Action{};}
 auto free=[&](int t){return t>=0&&board_.Current(t)&&(board_.at(t).occupant<0||board_.at(t).occupant==spawn_.id);};
 if(ring_.empty()&&length_>=4&&round_<100&&FreeSlots()>1&&int(body_.size())==length_&&SplitSafe(length_-2))
  return Because("ring: bootstrap shorten",bot::Action::Split(length_-2));
 if(ring_.empty()&&length_<=3&&int(body_.size())==length_) {
  double best=-1e30;std::vector<int> selected;
  for(auto [w,h]:std::vector<std::pair<int,int>>{{2,2},{3,2},{2,3}}) {
   if(2*(w+h)-4>RING_SIZE)continue;
   for(int x=board_.X(head_)-w+1;x<=board_.X(head_);++x)for(int y=board_.Y(head_)-h+1;y<=board_.Y(head_);++y) {
    if(x<0||y<0||x+w>board_.width()||y+h>board_.height())continue;
    auto base=rectangle(board_,x,y,w,h);
    for(int reverse=0;reverse<2;++reverse) {
     auto r=base;if(reverse)std::reverse(r.begin(),r.end());
     auto at=std::find(r.begin(),r.end(),head_);if(at==r.end())continue;std::rotate(r.begin(),at,r.end());
     bool good=true;std::set<int> exits;
     for(size_t i=0;i<r.size();++i) {
      if(!free(r[i]))good=false;
      bool edge=false;for(int d=0;d<4;++d)if(board_.Step(r[i],d)==r[(i+1)%r.size()])edge=true;
      if(!edge)good=false;
      for(int d=0;d<4;++d){int n=board_.Step(r[i],d);if(n>=0&&std::find(r.begin(),r.end(),n)==r.end()&&free(n))exits.insert(n);}
     }
     for(int i=1;i<length_;++i)if(body_[i]!=r[r.size()-i])good=false;
     if(!good||exits.size()<2)continue;
     // Prefer a six-cell loop with room for a three-cell child, then outside escape room.
     double score=10*int(r.size())+exits.size();
     if(score>best){best=score;selected=r;}
    }
   }
  }
  ring_=selected;
 }
 if(ring_.empty())return bot::Action{};
 ring_seen_=round_;
 auto pos=std::find(ring_.begin(),ring_.end(),head_);
 if(pos==ring_.end()){ring_.clear();return bot::Action{};}
 int next=ring_[(pos-ring_.begin()+1)%ring_.size()];
 bool danger=false;
 for(const auto& [id,e]:seen_)if(e.team!=spawn_.team&&e.round==round_&&e.head>=0) {
  int reach=std::min(8,std::max(3,(e.length+3)/4+e.length-2));
  auto paths=Search(board_,e.head,[&](int t){return t==head_||t==next||!Occupied(t);},reach);
  if((paths.dist[head_]>=0&&paths.dist[head_]<=reach)||(paths.dist[next]>=0&&paths.dist[next]<=reach))danger=true;
 }
 if(danger){ring_.clear();return bot::Action{};}
 const int threshold=ring_.size()==4?4:5;
 if(length_>=threshold&&FreeSlots()>0&&int(body_.size())==length_&&!(round_==499&&free(next)&&!Mine(next))) {
  int split=round_==499?2:length_-2;
  return Because(ring_.size()==4?"ring: pearl split two":"ring: pearl split three",bot::Action::Split(split));
 }
 if(free(next)&&!Mine(next))for(int d=0;d<4;++d)if(board_.Step(head_,d)==next) {
  body_.push_front(next);if(!board_.at(next).pearl)body_.pop_back();bot::Action a;a.steps={d};return Because("ring: pearl patrol",a);
 }
 ring_.clear();return bot::Action{};
}
bot::Action StrategyAgent::RingChildEscape() {
 if(int(body_.size())!=length_)return bot::Action::Resign();
 auto inside=[&](int t){return std::find(ring_.begin(),ring_.end(),t)!=ring_.end();};
 struct Route{std::vector<int> body,steps,eaten;};
 std::vector<Route> beam{{std::vector<int>(body_.begin(),body_.end()),{}, {}}};
 const int free_steps=(length_+3)/4;
 for(int depth=0;depth<6;++depth) {
  std::vector<Route> next;
  for(const auto& r:beam)for(int d=0;d<4;++d) {
   int t=board_.Step(r.body.front(),d);
   if(t<0||!board_.Current(t)||inside(t)||std::find(r.body.begin(),r.body.end(),t)!=r.body.end())continue;
   auto& cell=board_.at(t);if(cell.occupant>=0&&cell.occupant!=spawn_.id)continue;
   if(cell.occupant==spawn_.id&&std::find(body_.begin(),body_.end(),t)==body_.end())continue;
   bool pay=depth>=free_steps;if(pay&&r.body.size()<=2)continue;
   Route n=r;n.steps.push_back(d);n.body.insert(n.body.begin(),t);
   if(cell.pearl&&std::find(n.eaten.begin(),n.eaten.end(),t)==n.eaten.end())n.eaten.push_back(t);else n.body.pop_back();
   if(pay)n.body.pop_back();
   if(std::none_of(n.body.begin(),n.body.end(),inside)&&EscapeLevel(n.body,EscapeCap(n.body.size()))>0) {
    body_.assign(n.body.begin(),n.body.end());bot::Action a;a.steps=n.steps;return a;
   }
   next.push_back(std::move(n));
  }
  std::stable_sort(next.begin(),next.end(),[&](const Route&a,const Route&b){return std::count_if(a.body.begin(),a.body.end(),inside)<std::count_if(b.body.begin(),b.body.end(),inside);});
  if(next.size()>32)next.resize(32);beam=std::move(next);
 }
 return bot::Action::Resign();
}
bot::Action StrategyAgent::RingWorker(bot::Action normal,const rl::Observation& o) {
 ring_worker_override_=false;
 if(ring_child_release_>=0&&round_>=ring_child_release_) {rescue_committed_=true;ring_worker_override_=true;return Because("ring: return capacity outside",bot::Action::Resign());}
 for(uint64_t word:o.inbox)if((word>>56)==0xB8) {
  int stamp=(word>>16)&511,age=(round_-stamp)&511;
  int x=word&63,y=(word>>6)&63,w=(word>>12)&3,h=(word>>14)&3;
  if(age<=12&&w>=2&&h>=2&&w+h<=5&&x+w<=board_.width()&&y+h<=board_.height()) {ring_=rectangle(board_,x,y,w,h);ring_seen_=round_-age;}
 }
 if(round_-ring_seen_>12)ring_.clear();
 if(normal.kind==bot::Action::kSplit&&FreeSlots()<=1) {normal=SafeStep(FleeDirection(),false,false);rescue_committed_=true;ring_worker_override_=true;}
 if(ring_.empty())return normal;
 auto inside=[&](int t){return std::find(ring_.begin(),ring_.end(),t)!=ring_.end();};
 if(born_==round_&&!leader_&&int(body_.size())==length_&&std::all_of(body_.begin(),body_.end(),inside)) {
  rescue_committed_=true;ring_worker_override_=true;
  if(length_>=3) {auto a=RingChildEscape();if(!a.resign){if(FreeSlots()==0)ring_child_release_=round_+1;return Because("ring: child escape",a);}}
  return Because("ring: child immediate clearance",bot::Action::Resign());
 }
 // Keep the loop clear and reserve two currently observed exterior cells, allowing other workers to grow.
 std::set<int> external;
 for(int tile:ring_)for(int d=0;d<4;++d){int t=board_.Step(tile,d);if(t>=0&&board_.Current(t)&&!inside(t)&&board_.at(t).occupant<0)external.insert(t);}
 std::vector<int> blocked=ring_;for(int t:external){if(blocked.size()>=ring_.size()+2)break;blocked.push_back(t);}
 auto reserved=[&](int t){return std::find(blocked.begin(),blocked.end(),t)!=blocked.end();};
 bool enters=false;int t=head_;
 if(normal.kind==bot::Action::kMove&&!normal.resign)for(int d:normal.steps){t=board_.Step(t,d);if(t<0)break;if(reserved(t))enters=true;}
 if(normal.kind==bot::Action::kSplit)for(int tile:body_)if(inside(tile))enters=true;
 if(!enters)return normal;
 for(int d=0;d<4;++d){int n=board_.Step(head_,d);if(n<0||reserved(n)||Classify(n)!=Cell::kFree)continue;std::vector<int>b(body_.begin(),body_.end());b.insert(b.begin(),n);if(!board_.at(n).pearl)b.pop_back();if(EscapeLevel(b,EscapeCap(length_))==0)continue;rescue_committed_=true;ring_worker_override_=true;bot::Action a;a.steps={d};return Because("ring: worker yield loop",a);}
 return normal;
}
}
