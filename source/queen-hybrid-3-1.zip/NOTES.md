# queen-hybrid-3

Parent: queen-hybrid-2. Hypothesis: arena data (60 queen-decided games, replays decoded) shows
queens of length 2-3 attempt illegal splits and die (19/19 fatal splits). A short enemy queen is
a cheap trade worth taking even when outnumbered. Change: drop the outnumbered gate for hunting
and queen-kill trades when the enemy queen is length <= 3.
