# queen-ring17-hunt-3

Parent: queen-ring17-hunt-1. Ablation of hunt-2: the illegal-split guard applies to the queen only, and
workers keep their original split behaviour. Tests whether the queen survival gain holds without
changing worker splits (hunt-2 raised survival but the enemy-queen kill rate fell from 70 to 37 percent).
