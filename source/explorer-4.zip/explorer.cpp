// explorer-2: explore and farm pearls, by search instead of tuned heuristics. An
// experiment, measured alone with tools/solo.
//
// One objective: expected pearls eaten, discounted by kGamma per round. Three parts:
//
//   1. Survival lookahead. A depth-first search over the dragon's exact body states (the
//      engine's rules: a step into any own segment, tail included, kills; a step that eats
//      keeps the tail) looks for L + 1 more steps it could take without dying, other dragons
//      frozen where they are seen, unseen tiles blocked: a check under those assumptions,
//      not a guarantee. The plan whose end state lasts longest is taken.
//   2. Beam search over moves. States are exact bodies; turns have the real sprint structure
//      (ceil(L/4) free steps, a turn may stop early, never a paid step). A step earns the
//      pearl expected on its tile at its arrival round (pearls seen; beds, whose next pearl
//      round is seen as their countdown), plus the pearls expected on the tiles it brings
//      into view (the bed density measured so far).
//   3. A value field for the search's leaves: every target's value spread over the board,
//      discounted by distance (multi-source Dijkstra). A target counts only if this dragon
//      reaches it no later than every other dragon in view (a Voronoi split of the targets).
//
// Sonar: every turn each dragon pings its four directions with four tiles of its map (beds
// first, then maze structure, then the rest; what it heard from others included), and merges
// every tile it hears into its own. So the survival search and the planner see the maze that
// any dragon in sonar reach has seen. A word is 56 bits; a tile takes 54 (sonar.hpp).
//
// Splits follow the user's rule: many short dragons early (split at length 4), up to one
// dragon per kTilesPerDragon tiles, and only if parent and child both pass the survival search.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <deque>
#include <limits>
#include <queue>
#include <unordered_map>
#include <vector>
#include <chrono>

#include "team_memory.hpp"
#include "plugin.hpp"
#include "sonar.hpp"

namespace {

using ex2::TeamMemory;
using ex2::TileMemory;

// the rules of play
constexpr int kSplitAt = 4;               // the user's call: many short dragons early
constexpr int kTilesPerDragon = 16;       // team cap: board tiles / this
constexpr int kMaxDragons = 64;
constexpr int kLastSplitRound = 440;
// the objective and the search
constexpr double kGamma = 0.95;           // per round
constexpr int kBeam = 48;                 // states kept per depth (for a short dragon; fewer when long)
constexpr int kHorizon = 12;              // steps searched
constexpr int kSurviveBudget = 1500;      // survival search nodes; past it, assume a way out
constexpr int kQueenBudget = 20000;       // the queen's lookahead budget (out of it counts as no way out)
constexpr int kPlansChecked = 8;          // plans (best first) given the survival lookahead
constexpr int kRingMask = 4095;
constexpr double kMaxValue = 64;          // above the most one tile can be worth (pearl + its 49-tile view): the field's level 0           // the survival search's body ring
constexpr int kSurviveSteps = 6;         // a worker's lookahead must find this many steps on known ground (or L + 1)
constexpr int kQueenSteps = 24;           // ... the queen's
constexpr int kQueenBerth = 3;            // workers keep this far (steps) from their queen's head
constexpr double kBedPrior = 0.1;         // beds per tile before we've seen much
constexpr int kQueenNews = 4;             // rounds a heard queen position stays useful
constexpr int kQueenSplitUnits = 4;       // the queen splits early only while the team is smaller than this
constexpr double kQueenFullPearl = -2.0;  // a pearl's worth to a queen at her length
constexpr int kQueenReserve = 4;
constexpr int kCorneredSteps = 3;         // before settling, the queen calls for room when she can't last L + this
constexpr int kDistressRadius = 6;        // workers this close to a queen in distress resign to make room
constexpr int kRaceSteps = 6;             // the queen's escape over tiles she wins the race to (or L + 2)
constexpr int kLungeSteps = 12;           // how far a hunter runs onto a head it sees
constexpr int kShareRadius = 5;           // heads this close to a clash share its remains
constexpr int kNever = 1 << 20;          // units kept free for the queen's splits
constexpr int kSettleRound = 25;          // the queen settles her territory at this round
constexpr int kSettleUnits = 8;           // ... or once the team has this many dragons
constexpr int kHomeRadius = 3;
constexpr int kZoneSteps = 8;             // the queen's lookahead inside her walled territory
constexpr double kHomeValue = 8;          // what her home is worth to a queen outside her territory
constexpr int kHomeSearch = 12;           // she looks for her home this many steps around her            // the queen's territory: tiles this many steps from her home
constexpr double kInTerritory = 1.0;      // a worker's cost per step inside it
constexpr int kQueenMaxLen = 4;           // ... and later whenever she reaches this length (a short queen is easy to keep alive)
constexpr int kMateAge = 12;              // rounds a teammate's reported position still counts
constexpr int kResend = 30;               // a tile is sent again after this many rounds
constexpr bool kDebugTmp = false;
constexpr bool kQDebug = false;
constexpr bool kDebug = false;            // stderr traces; always false when committed
constexpr bool kProfile = false;          // stderr: turns over 1 ms, by phase; always false when committed

struct State {
  std::vector<int32_t> body;   // known segments, head first
  int unknown = 0;             // segments at the tail end whose tiles we don't know
  int len = 0;
  int round = 0;               // round of the turn in progress
  int left = 0;                // free steps left in that turn
  int in_turn = 0;             // steps taken in that turn
  int plan = -1;               // which first-turn plan this state continues
  double score = 0;            // reward so far
  double est = 0;              // score + the value field at the head
  std::vector<int32_t> eaten;  // tiles eaten on the way
  int32_t head() const { return body.front(); }
  bool InBody(int32_t t) const { return std::find(body.begin(), body.end(), t) != body.end(); }
};

struct Plan {
  std::vector<int> steps;
  State end;                   // the state when the first turn ends
  double best = -std::numeric_limits<double>::infinity();
};

class Explorer : public bot::Agent {
 public:
  explicit Explorer(const rl::Spawn& s)
      : spawn_(s), mem_(s.width, s.height), n_(s.width * s.height), wall_(n_), head_near_(n_), unseen_(n_),
        view_(n_), row_(n_), dist_me_(n_), dist_other_(n_), field_(n_), in_view_(n_, 0), last_sent_(n_, -1), occ_(n_, 0), ate_(n_, 0),
        sent_seen_(n_, -1) {}

  const char* reason() const override { return why_; }

  static double Now() { return std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now().time_since_epoch()).count(); }

  bot::Action Turn(const rl::Observation& o) override {
    if constexpr (kProfile) {
      const double t0 = Now();
      bot::Action a = TurnImpl(o);
      const double t1 = Now();
      if (t1 - t0 > 1000) std::fprintf(stderr, "SLOWTURN r%d id%d len%d %.0f us (%s)\n", round_, spawn_.id, len_, t1 - t0, why_);
      return a;
    }
    return TurnImpl(o);
  }

  bot::Action TurnImpl(const rl::Observation& o) {
    const double t_start = kProfile ? Now() : 0;
    last_lasts_ = kNever;   // a turn that doesn't search (a split) has no lookahead to be distressed by
    mem_.Update(o);
    int heard = 0;
    for (const uint64_t w : o.inbox) {
      sonar::TileMsg m;
      sonar::QueenMsg q;
      sonar::PosMsg pm;
      sonar::AlertMsg am;
      if (sonar::Decode(w, am)) {
        if (am.round <= o.round && am.x < spawn_.width && am.y < spawn_.height && am.round >= hunter_round_)
          hunter_heard_ = mem_.Tile(am.x, am.y), hunter_round_ = am.round;
      }
      else if (sonar::Decode(w, pm)) {
        if (pm.id != spawn_.id && pm.round <= o.round && pm.x < spawn_.width && pm.y < spawn_.height) {
          if (static_cast<size_t>(pm.id) >= mates_.size()) mates_.resize(pm.id + 1);
          if (static_cast<size_t>(pm.id) >= relayed_.size()) relayed_.resize(pm.id + 1, -1);
          if (pm.round > mates_[pm.id].round) mates_[pm.id] = {mem_.Tile(pm.x, pm.y), pm.round};
        }
      }
      else if (sonar::Decode(w, m)) mem_.Merge(m.x, m.y, m.north, m.west, m.next_pearl, m.pearl, m.seen), ++heard;
      else if (sonar::Decode(w, q) && q.round <= o.round && q.x < spawn_.width && q.y < spawn_.height &&
               q.home_x < spawn_.width && q.home_y < spawn_.height) {
        if (q.round > queen_round_) queen_at_ = mem_.Tile(q.x, q.y), queen_round_ = q.round;
        if (q.distress && q.round >= o.round - 1 && !IsQueen()) distress_heard_ = mem_.Tile(q.x, q.y);
        if (home_ < 0 && !IsQueen() && !q.distress) home_ = mem_.Tile(q.home_x, q.home_y);   // a distress call may predate her home
      }
    }
    if constexpr (kDebug) std::fprintf(stderr, "HEARD %d %zu\n", heard, o.inbox.size());
    for (int32_t t = 0; t < n_; ++t)   // the step graph as known now, for every search this turn
      for (int d = 0; d < 4; ++d) adj_[4 * t + d] = mem_.Step(t, d);
    std::fill(in_view_.begin(), in_view_.end(), 0);
    for (int k = 0; k < rl::kWindowTiles; ++k) in_view_[mem_.Tile(o.tile_x[k], o.tile_y[k])] = 1;
    round_ = o.round;
    len_ = o.length;
    const int32_t head = mem_.Tile(o.head_x(), o.head_y());
    Track(o, head);
    Observe(o);
    // early on she explores like any dragon (few dragons, no crowd); she settles a territory
    // where she stands once the team has grown
    if (IsQueen() && home_ < 0 && (round_ >= kSettleRound || o.unit_count >= kSettleUnits)) home_ = ChooseHome(head);
    Territory(head, now_len_hint());
    alert_ = -1;
    if (IsQueen() && !hunt_[head].empty()) alert_ = hunt_[head][0].from;
    if (IsQueen()) {
      Contest(o);
      queen_at_ = head, queen_round_ = round_;
      // every dragon that steps through a portal blind lands on a portal mouth (the tile beside
      // a portal edge), on its own turn: the queen never ends her turn on one, so no blind
      // step can land on her head (passing over one is fine)
      for (int32_t t = 0; t < n_; ++t) mouth_[t] = mem_.at(t).seen_round >= 0 && PortalMouth(t);
    }
    else ApplyBerth(head);

    // the body: known from the trail of the head, the rest unknown (out of view)
    State now;
    const int known = std::min<int>(len_, static_cast<int>(trail_.size()));
    for (int i = 0; i < known; ++i) now.body.push_back(trail_[trail_.size() - 1 - i]);
    now.unknown = len_ - known;
    now.len = len_;
    now.round = round_;
    now.left = (len_ + 3) / 4;

    // a worker that sees our queen runs her lookahead: if she can't last L + kCorneredSteps with
    // our body where it is, but could without it, we're what boxes her in: we give her our tiles
    // ... but our body won't stay where it is: she moves before we do again, and by then we have
    // taken our steps (the tail follows the head). Only if she'd still be boxed in by where this
    // turn's plan leaves us do we give up our tiles (decided once the plan is known, below).
    const bool maybe_blocking = !IsQueen() && BlockingQueen(o, now);

    const double t_pre = kProfile ? Now() : 0;
    // workers leave kQueenReserve of the unit limit free: the queen can always split (to escape
    // or to stay short); a split at the limit is death
    const bool may_split = IsQueen() ? (o.unit_count < kQueenSplitUnits || len_ >= kQueenMaxLen) && o.unit_count < spawn_.unit_limit - 1
                                     : o.unit_count < std::min(Cap(), spawn_.unit_limit - kQueenReserve);
    // a queen at her length stops growing: pearls cost her (a short queen is the easy one to keep alive)
    // ... and so does one who can't split now (the team at the unit limit): she'd only grow
    eat_value_ = IsQueen() && (len_ >= kQueenMaxLen || o.unit_count >= spawn_.unit_limit - 1) ? kQueenFullPearl : 1.0;
    if (len_ >= kSplitAt && now.unknown == 0 && may_split && round_ <= kLastSplitRound && SplitSafe(now)) {
      why_ = "split";
      bot::Action a = bot::Action::Split(len_ / 2);
      Talk(a);
      return a;
    }

    // our queen called for room and we're near her: give her our tiles
    if (distress_heard_ >= 0) {
      const int32_t q = distress_heard_;
      distress_heard_ = -1;
      int dx = std::abs(mem_.X(head) - mem_.X(q)), dy = std::abs(mem_.Y(head) - mem_.Y(q));
      dx = std::min(dx, spawn_.width - dx), dy = std::min(dy, spawn_.height - dy);
      if (dx + dy <= kDistressRadius) {
        why_ = "make room for the queen";
        if (kDebugTmp) std::fprintf(stderr, "DISTRESS r%d id%d\n", round_, spawn_.id);
        return bot::Action::Resign();
      }
    }
    // a probe we sent through a portal last turn: if its echo met no dragon, the tile past the
    // portal was empty (the ping crossed it first), so step through now and see what's there
    if (probe_tile_ == head && probe_round_ == round_ - 1 && o.echo_present && !IsQueen() && BlindPortal(head, probe_dir_)) {
      // ECHOES: kelp, ally body, ally head, enemy body, enemy head. Any dragon on the ray vetoes
      // the crossing: it may lie past the landing tile, but it may be our queen about to step
      // onto it (a body echo too: her body now, her head next).
      int echo[5];
      for (int f = 0; f < 5; ++f) echo[f] = static_cast<int>(std::strtol(o.echo[f].c_str(), nullptr, 10));
      const bool heads = echo[2] + echo[4] > 0, bodies = echo[1] + echo[3] > 0;
      probe_tile_ = -1;
      if (!heads && !bodies) {
        why_ = "through portal";
        if constexpr (kDebug) std::fprintf(stderr, "CROSS r%d id%d at (%d,%d) dir %c echo %s %s %s %s %s\n", round_, spawn_.id, mem_.X(head), mem_.Y(head), "NESW"[probe_dir_], o.echo[0].c_str(), o.echo[1].c_str(), o.echo[2].c_str(), o.echo[3].c_str(), o.echo[4].c_str());
        crossing_ = true;
        bot::Action a = bot::Action::Move(probe_dir_);
        Talk(a);
        return a;
      }
    }
    probe_tile_ = -1;

    if (!IsQueen()) {
      const std::vector<int> path = Intercept(head, now);
      if (!path.empty()) {
        why_ = "intercept";
        bot::Action a;
        a.kind = bot::Action::kMove;
        int32_t at = head;
        for (int d : path) a.steps.push_back(d), at = Adj(at, d), trail_.push_back(at);
        Talk(a);
        return a;
      }
    }

    const double t_split = kProfile ? Now() : 0;
    CountUnseen();
    BuildField(now);
    const double t_field = kProfile ? Now() : 0;
    std::vector<int> steps = Search(now);
    if constexpr (kProfile) {
      const double t_end = Now();
      if (t_end - t_start > 1000)
        std::fprintf(stderr, "SLOW r%d id%d len%d: update %.0f split %.0f field %.0f search %.0f (plans %zu)\n", round_, spawn_.id,
                     len_, t_pre - t_start, t_split - t_pre, t_field - t_split, t_end - t_field, plans_.size());
    }
    // no move, or none that lasts past this turn: maybe a split frees us (escape split)
    // the queen in trouble inside her territory: drop the boundary for this turn and plan again
    if (IsQueen() && !walled_.empty() && (steps.empty() || last_lasts_ < QueenNeed(len_))) {
      for (int32_t t : walled_) wall_[t] = 0;
      walled_.clear();
      BuildField(now);
      steps = Search(now);
    }
    // a worker with no step left because of the berth it keeps around its queen: the berth is a
    // courtesy, her head's neighbours are the part that matters (she never steps beside a head)
    if (!IsQueen() && berth_ > 1 && round_ < kSettleRound && (steps.empty() || last_lasts_ < 2)) {
      berth_ = 1;
      Observe(o);
      ApplyBerth(head);
      BuildField(now);
      std::vector<int> again = Search(now);
      berth_ = kQueenBerth;
      if (!again.empty()) steps = std::move(again);
    }
    const int split_room = IsQueen() ? spawn_.unit_limit : spawn_.unit_limit - kQueenReserve;
    if ((steps.empty() || last_lasts_ < (IsQueen() ? 2 : Need(len_, false))) && now.unknown == 0 && len_ >= 4 && o.unit_count < split_room) {
      if (const int n = EscapeSplit(now, steps.empty() ? 0 : last_lasts_); n > 0) {
        why_ = "escape split";
        bot::Action a = bot::Action::Split(n);
        Talk(a);
        return a;
      }
    }
    // can't last, and part of our body is out of view: the child walks out of the unseen end
    // (it sees its own surroundings next turn); the parent keeps the part we can plan with
    if (!IsQueen() && now.unknown >= 2 && len_ >= 4 && o.unit_count < split_room && (steps.empty() || last_lasts_ < Need(len_, false))) {
      why_ = "escape split (unseen tail)";
      bot::Action a = bot::Action::Split(std::min(now.unknown, len_ - 2));
      Talk(a);
      return a;
    }
    if (steps.empty()) {
      if constexpr (kDebug) {
        std::fprintf(stderr, "NOWAY r%d id%d len%d unk%d head(%d,%d) units%d body", round_, spawn_.id, len_, now.unknown,
                     mem_.X(head), mem_.Y(head), o.unit_count);
        for (int32_t t : now.body) std::fprintf(stderr, " %d,%d", mem_.X(t), mem_.Y(t));
        std::fprintf(stderr, " | home %d inzone %d walled %zu", home_, home_ >= 0 ? zone_[head] : -1, walled_.size());
        std::fprintf(stderr, " | nbrs");
        for (int d = 0; d < 4; ++d) {
          const int32_t t = Adj(head, d);
          std::fprintf(stderr, " %c:%s", "NESW"[d], t < 0 ? (t == ex2::kBlocked ? "kelp" : "unk") : wall_[t] ? "wall" : now.InBody(t) ? "own" : head_near_[t] ? "nearhead" : "free");
        }
        std::fprintf(stderr, "\n");
      }
      why_ = "no way out";   // die alone: never into a sibling's head
      return bot::Action::Resign();
    }
    if (maybe_blocking) {
      State end = now;
      for (int d : steps) {
        const int32_t t = Adj(end.head(), d);
        end.body.insert(end.body.begin(), t);
        if (PearlAt(t, round_, &end) > 0) end.eaten.push_back(t), ++end.len;
        else if (end.unknown > 0) --end.unknown;
        else end.body.pop_back();
      }
      if (kDebugTmp) std::fprintf(stderr, "MB r%d id%d steps%zu\n", round_, spawn_.id, steps.size());
      if (BlockingQueen(o, end)) {
        why_ = "make room for the queen";
        return bot::Action::Resign();
      }
    }
    if (IsQueen() && len_ > kQueenMaxLen && chosen_plan_ >= 0) Shrink(now, steps);
    bot::Action a;
    a.kind = bot::Action::kMove;
    int32_t at = head;
    for (int d : steps) {
      a.steps.push_back(d);
      at = Adj(at, d);
      trail_.push_back(at);
    }
    // ending beside a portal whose far side we can't see: probe it (one ping, so its echo is ours
    // alone) if it's unexplored, or leads somewhere worth at least where we are
    const int back = (steps.back() + 2) % 4;
    for (int d = 0; d < 4 && !IsQueen(); ++d)
      if (d != back && in_view_[at] && BlindPortal(at, d) && (Adj(at, d) == ex2::kUnknown || field_[Adj(at, d)] >= field_[at])) {
        a.sonar[d] = 1;
        probe_tile_ = at, probe_dir_ = d, probe_round_ = round_;
        return a;
      }
    Talk(a);
    if constexpr (kQDebug) if (IsQueen()) {
      std::fprintf(stderr, "Q r%d len%d at(%d,%d) %s steps:", round_, len_, mem_.X(head), mem_.Y(head), why_);
      for (int d : steps) std::fprintf(stderr, " %c", "NESW"[d]);
      std::fprintf(stderr, " | lasts %d | heads:", last_lasts_);
      for (const rl::Segment& sg : o.segments) if (sg.head && sg.id != spawn_.id) std::fprintf(stderr, " %c%d(%d,%d)", sg.team == spawn_.team ? 'a' : 'E', sg.id, sg.x, sg.y);
      std::fprintf(stderr, " units %d\n", o.unit_count);
    }
    if constexpr (kDebug) {
      std::fprintf(stderr, "r%d id%d len%d (%d,%d) %s:", round_, spawn_.id, len_, mem_.X(head), mem_.Y(head), why_);
      for (int d : steps) std::fprintf(stderr, " %c", "NESW"[d]);
      int pearls = 0, reach_pearls = 0, beds = 0;
      for (int32_t t = 0; t < n_; ++t) {
        if (mem_.at(t).pearl) { ++pearls; if (dist_me_[t] >= 0) ++reach_pearls; }
        if (mem_.at(t).countdown >= 0) ++beds;
      }
      int unpaired = 0, paired = 0;
      for (int32_t t = 0; t < n_; ++t)
        if (mem_.at(t).seen_round >= 0)
          for (int d = 0; d < 4; ++d) {
            const int32_t u = Adj(t, d);
            if (u == ex2::kUnknown) ++unpaired;
            else if (u >= 0 && u != mem_.Tile(mem_.X(t) + dragons::kDx[d], mem_.Y(t) + dragons::kDy[d])) ++paired;
          }
      std::fprintf(stderr, " | plans %zu lasts %d inzone %d walled %zu units %d\n", plans_.size(), last_lasts_, home_ >= 0 ? zone_[head] : -1, walled_.size(), o.unit_count);
    }
    return a;
  }

 private:
  int32_t Adj(int32_t t, int d) const { return adj_[4 * t + d]; }
  bool IsQueen() const { return spawn_.id <= 1; }
  int now_len_hint() const { return len_; }

  // Tiles within kHomeRadius steps of c over the known map, and how many of them are portal mouths.
  int ZoneSize(int32_t c, int* mouths) {
    zone_q_.assign(1, c);
    std::vector<int32_t> depth(1, 0);
    zone_[c] = 1;
    for (size_t h = 0; h < zone_q_.size(); ++h) {
      if (depth[h] >= kHomeRadius) continue;
      for (int d = 0; d < 4; ++d) {
        const int32_t v = Adj(zone_q_[h], d);
        if (v < 0 || zone_[v]) continue;
        zone_[v] = 1, zone_q_.push_back(v), depth.push_back(depth[h] + 1);
      }
    }
    *mouths = 0;
    for (int32_t t : zone_q_) *mouths += PortalMouth(t), zone_[t] = 0;
    return static_cast<int>(zone_q_.size());
  }
  // Her home: of the known tiles within kHomeSearch steps, the most open ground (the largest
  // territory) with the fewest portal mouths, nearer first.
  int32_t ChooseHome(int32_t head) {
    std::vector<int32_t> dist(n_, -1);
    Distances({head}, dist);
    int32_t best = head;
    double best_score = -1e18;
    for (int32_t t = 0; t < n_; ++t) {
      if (dist[t] < 0 || dist[t] > kHomeSearch || mem_.at(t).seen_round < 0) continue;
      int mouths = 0;
      const int size = ZoneSize(t, &mouths);
      const double score = size - 4.0 * mouths - 0.5 * dist[t];
      if (score > best_score) best_score = score, best = t;
    }
    return best;
  }

  // The queen's territory: tiles within kHomeRadius steps of her home (over the known map).
  // Every step a worker takes inside it costs kInTerritory, so workers keep out where they can
  // and a fresh split child walks out, but a route through a choke point stays open. The queen
  // keeps inside it, as long as her lookahead can last there (else, this turn, anywhere).
  void Territory(int32_t head, int len) {
    std::fill(zone_.begin(), zone_.end(), 0);
    if (home_ < 0) return;
    zone_q_.assign(1, home_);
    zone_[home_] = 1;
    std::vector<int32_t> depth(1, 0);
    for (size_t h = 0; h < zone_q_.size(); ++h) {
      if (depth[h] >= kHomeRadius) continue;
      for (int d = 0; d < 4; ++d) {
        const int32_t v = Adj(zone_q_[h], d);
        if (v < 0 || zone_[v]) continue;
        zone_[v] = 1;
        zone_q_.push_back(v);
        depth.push_back(depth[h] + 1);
      }
    }
    if (!IsQueen()) {
      // a worker outside: the territory is walls, unless walling it would cut the worker off
      // from known ground beyond it (a home in a choke point): then it only costs (Step)
      if (zone_[head]) return;
      Distances({head}, dist_me_);
      for (int32_t t : zone_q_) wall_[t] += 1;
      Distances({head}, dist_other_);
      bool cuts = false;
      for (int32_t t = 0; t < n_ && !cuts; ++t) cuts = !zone_[t] && dist_me_[t] >= 0 && dist_other_[t] < 0;
      if (cuts)
        for (int32_t t : zone_q_) wall_[t] -= 1;
      return;
    }
    if (!zone_[head]) return;
    std::vector<int32_t>& walled = walled_;
    walled.clear();
    for (int32_t t = 0; t < n_; ++t)
      if (!zone_[t] && !wall_[t]) wall_[t] = 1, walled.push_back(t);
    State s;
    const int known = std::min<int>(len, static_cast<int>(trail_.size()));
    for (int i = 0; i < known; ++i) s.body.push_back(trail_[trail_.size() - 1 - i]);
    s.unknown = len - known;
    s.len = len;
    s.round = round_;
    if (s.body.empty() || Lasts(s, ZoneNeed(len)) < ZoneNeed(len)) {   // she can't last inside: no boundary this turn
      for (int32_t t : walled) wall_[t] = 0;
      walled.clear();
    }
  }

  // a step from t toward d that goes through a portal to a tile out of view (or unpaired)
  bool BlindPortal(int32_t t, int d) const {
    const int32_t u = Adj(t, d);
    if (u == ex2::kUnknown) return mem_.at(t).seen_round >= 0;
    return u >= 0 && !in_view_[u] && u != mem_.Tile(mem_.X(t) + dragons::kDx[d], mem_.Y(t) + dragons::kDy[d]);
  }
  bool PortalMouth(int32_t t) const {
    for (int d = 0; d < 4; ++d) {
      const int32_t u = Adj(t, d);
      if (u == ex2::kUnknown || (u >= 0 && u != mem_.Tile(mem_.X(t) + dragons::kDx[d], mem_.Y(t) + dragons::kDy[d]))) return true;
    }
    return false;
  }
  // Where our queen's head was lately (seen, or heard over sonar): a blind step (through a
  // portal, out of view) must not land where she could be by then.
  bool QueenHeardRecently() const { return !IsQueen() && queen_at_ >= 0 && round_ - queen_round_ <= kQueenNews; }
  bool NearQueen(int32_t t) const {
    if (!QueenHeardRecently()) return false;
    const int W = spawn_.width, H = spawn_.height;
    int dx = std::abs(mem_.X(t) - mem_.X(queen_at_)), dy = std::abs(mem_.Y(t) - mem_.Y(queen_at_));
    dx = std::min(dx, W - dx), dy = std::min(dy, H - dy);
    return dx + dy <= kQueenBerth + 2 * (round_ - queen_round_ + 1);   // she moves up to ~2 tiles a round
  }
  int Cap() const { return std::clamp(n_ / kTilesPerDragon, 1, kMaxDragons); }

  // Four tiles to tell the team, one per direction: the ones with the most to say that we
  // haven't sent (or have newer news of, or sent kResend rounds ago). A bed beats maze
  // structure (a kelp or portal edge) beats open ground; then the freshest.
  void Talk(bot::Action& a) {
    if (IsQueen() && alert_ >= 0) {   // a hunter sees her: every ping calls the workers onto it
      sonar::AlertMsg am{mem_.X(alert_), mem_.Y(alert_), round_};
      uint64_t w;
      if (sonar::Encode(am, w)) {
        for (int d = 0; d < 4; ++d) a.sonar[d] = w;
        return;
      }
    }
    int32_t pick[4] = {-1, -1, -1, -1};
    long score[4] = {-1, -1, -1, -1};
    for (int32_t t = 0; t < n_; ++t) {
      const TileMemory& m = mem_.at(t);
      if (m.seen_round < 0 || !mem_.EdgesKnown(t)) continue;
      const bool news = last_sent_[t] < 0 || m.seen_round > sent_seen_[t];
      if (!news && round_ - last_sent_[t] < kResend) continue;
      const int base = m.countdown >= 0 ? 3 : (mem_.North(t) != dragons::kEdgeEmpty || mem_.West(t) != dragons::kEdgeEmpty) ? 2 : 1;
      const long sc = (news ? 4000L : 0L) + base * 1000L + m.seen_round;
      int worst = 0;
      for (int i = 1; i < 4; ++i)
        if (score[i] < score[worst]) worst = i;
      if (sc > score[worst]) score[worst] = sc, pick[worst] = t;
    }
    // distress, every direction calling for room: once settled, when she can't last her
    // territory's lookahead; before that, only when she's truly cornered (not when she merely
    // knows too little of the map to see far)
    if (IsQueen() && a.kind != bot::Action::kSplit && (home_ >= 0 ? last_lasts_ < QueenNeed(len_) : last_lasts_ < len_ + kCorneredSteps)) {
      const int32_t h = home_ >= 0 ? home_ : queen_at_;
      sonar::QueenMsg q{mem_.X(queen_at_), mem_.Y(queen_at_), round_, mem_.X(h), mem_.Y(h), true};
      uint64_t w;
      if (sonar::Encode(q, w))
        for (int d = 0; d < 4; ++d) a.sonar[d] = w;
      return;
    }
    int queen_dir = -1;   // one ping carries our queen: where she was, when, and her home (from her, or relayed)
    if (queen_at_ >= 0 && home_ >= 0) {
      queen_dir = round_ % 4;
      sonar::QueenMsg q{mem_.X(queen_at_), mem_.Y(queen_at_), IsQueen() ? round_ : queen_round_, mem_.X(home_), mem_.Y(home_)};
      uint64_t w;
      if (sonar::Encode(q, w)) a.sonar[queen_dir] = w;
    }
    int pos_dir = -1;   // one ping carries where we are (and when), for the others' target split
    if (!trail_.empty()) {
      pos_dir = (round_ + 1) % 4;
      if (pos_dir == queen_dir) pos_dir = (pos_dir + 1) % 4;
      sonar::PosMsg pm{mem_.X(trail_.back()), mem_.Y(trail_.back()), round_, spawn_.id};
      // every other turn we pass on the teammate we heard of longest ago that is still news
      // (so positions travel past the reach of a single ping)
      if (round_ % 2 == 1) {
        int pick_id = -1;
        for (size_t id = 0; id < mates_.size(); ++id)
          if (mates_[id].tile >= 0 && static_cast<int>(id) != spawn_.id && round_ - mates_[id].round <= kMateAge &&
              mates_[id].round > relayed_[id] && (pick_id < 0 || mates_[id].round > mates_[pick_id].round))
            pick_id = static_cast<int>(id);
        if (pick_id >= 0) pm = {mem_.X(mates_[pick_id].tile), mem_.Y(mates_[pick_id].tile), mates_[pick_id].round, pick_id}, relayed_[pick_id] = pm.round;
      }
      uint64_t w;
      if (sonar::Encode(pm, w)) a.sonar[pos_dir] = w;
    }
    for (int d = 0; d < 4; ++d) {
      if (d == queen_dir || d == pos_dir) continue;
      const int32_t t = pick[d];
      if (t < 0) continue;
      const TileMemory& m = mem_.at(t);
      sonar::TileMsg msg{mem_.X(t), mem_.Y(t), mem_.North(t), mem_.West(t),
                         m.countdown < 0 ? -1 : m.seen_round + std::max(m.countdown, 1), m.pearl, m.seen_round};
      uint64_t w;
      if (!sonar::Encode(msg, w)) continue;
      a.sonar[d] = w;
      last_sent_[t] = round_;
      sent_seen_[t] = m.seen_round;
    }
  }

  // The trail of the head: segment i of the body is trail[end - 1 - i]. When the whole body
  // is in view, DRAGON_BODIES lists it head to tail, so it is known exactly.
  void Track(const rl::Observation& o, int32_t head) {
    if (crossing_) trail_.push_back(head), crossing_ = false;   // we stepped through a portal: here is where it led
    if (trail_.empty() || trail_.back() != head) trail_.assign(1, head);
    if (trail_.size() > 4096) trail_.erase(trail_.begin(), trail_.end() - 2048);
    if (static_cast<int>(trail_.size()) < len_) {
      std::vector<int32_t> seen;
      for (const rl::Segment& sg : o.segments)
        if (sg.id == spawn_.id) seen.push_back(mem_.Tile(sg.x, sg.y));
      if (static_cast<int>(seen.size()) == len_ && seen.front() == head) trail_.assign(seen.rbegin(), seen.rend());
    }
  }

  // heard of (or seen) just now: keep clear of her
  void ApplyBerth(int32_t head) {
    if (queen_at_ < 0 || round_ - queen_round_ > 1) return;
    for (int dy = -berth_; dy <= berth_; ++dy)
      for (int dx = std::abs(dy) - berth_; dx <= berth_ - std::abs(dy); ++dx)
        if (const int32_t t = mem_.Tile(mem_.X(queen_at_) + dx, mem_.Y(queen_at_) + dy); t != head) wall_[t] = 1;
  }

  // Walls for this turn: other bodies in view (and our own segments in view that the
  // trail doesn't place); tiles next to another head; the bed density so far.
  void Observe(const rl::Observation& o) {
    std::fill(wall_.begin(), wall_.end(), 0);
    std::fill(head_near_.begin(), head_near_.end(), 0);
    std::fill(body_.begin(), body_.end(), 0);
    other_heads_.clear();
    seen_ids_.clear();
    const int known = std::min<int>(len_, static_cast<int>(trail_.size()));
    for (const rl::Segment& s : o.segments) {
      const int32_t t = mem_.Tile(s.x, s.y);
      if (s.id == spawn_.id) {
        bool placed = false;
        for (int i = 0; i < known && !placed; ++i) placed = trail_[trail_.size() - 1 - i] == t;
        if (!placed) wall_[t] = 1;
        continue;
      }
      wall_[t] = 1;
      body_[t] = 1;
      if (s.head && s.id <= 1 && s.team == spawn_.team) queen_at_ = t, queen_round_ = round_;
      if (s.head && s.id <= 1 && s.team == spawn_.team && !IsQueen())   // our queen: keep clear of her head
        for (int dy = -berth_; dy <= berth_; ++dy)
          for (int dx = std::abs(dy) - berth_; dx <= berth_ - std::abs(dy); ++dx) wall_[mem_.Tile(s.x + dx, s.y + dy)] = 1;
      if (s.head) {
        if (s.team == spawn_.team) seen_ids_.push_back(s.id);
        other_heads_.push_back(t);
        for (int d = 0; d < 4; ++d)
          if (const int32_t nb = Adj(t, d); nb >= 0) head_near_[nb] = 1;
      }
    }
    // What a tile newly brought into view is worth: its pearl, discounted by the rounds until it
    // pops. Measured on the beds seen so far (a bed whose countdown is 3000 is worth nothing
    // now; one that pops in 3 rounds nearly a pearl), smoothed toward a prior of kBedPrior
    // worth one 7x7 view.
    int seen = 0;
    double worth = 0;
    for (int32_t t = 0; t < n_; ++t) {
      const TileMemory& m = mem_.at(t);
      if (m.seen_round < 0) continue;
      ++seen;
      if (m.pearl) worth += 1;
      else if (m.countdown >= 0) worth += std::pow(kGamma, std::max(0, m.seen_round + std::max(m.countdown, 1) - round_));
    }
    density_ = (worth + kBedPrior * 49) / (seen + 49.0);
    Hunters(o);
  }

  // The enemy's reach. An enemy head that sees our head (its 7x7 window) runs onto it over
  // visible tiles, other bodies as walls: its first ceil(L/4) steps are free, each later one
  // costs a segment (up to L - 2 of them), at most kLungeSteps. A head-to-head kills both, so it
  // does so when the clash gains it: our length less its own, plus the remains (ceil(L/2)
  // pearls from each corpse) to whichever team has more heads around. hunt_[t] lists the
  // enemies that can be on t before our next turn; the price of ending a turn there is in EndTurn.
  void Hunters(const rl::Observation& o) {
    for (int32_t t : hunt_touched_) hunt_[t].clear();
    hunt_touched_.clear();
    struct E { int id, team; int32_t head; int seen = 0; bool edge = false; };
    std::vector<E> es;
    const int hx = o.head_x(), hy = o.head_y();
    auto find = [&](int id) -> E& {
      for (E& e : es) if (e.id == id) return e;
      es.push_back(E{id, 0, -1});
      return es.back();
    };
    for (const rl::Segment& sg : o.segments) {
      if (sg.id == spawn_.id) continue;
      E& e = find(sg.id);
      e.team = sg.team;
      ++e.seen;
      const int dx = std::abs(Wrap(spawn_.width, sg.x - hx)), dy = std::abs(Wrap(spawn_.height, sg.y - hy));
      if (std::max(dx, dy) >= 3) e.edge = true;   // the body may run on out of view
      if (sg.head) e.head = mem_.Tile(sg.x, sg.y);
    }
    std::vector<int32_t> dist(n_, -1);
    std::vector<int32_t> q;
    for (const E& e : es) {
      if (e.team == spawn_.team || e.head < 0) continue;
      const int len = e.seen + (e.edge ? 4 : 0);
      if (len < 3) continue;   // a length-2 dragon has no step to spare
      const int free_steps = (len + 3) / 4;
      const int budget = std::min(kLungeSteps, free_steps + len - 2);
      std::fill(dist.begin(), dist.end(), -1);
      q.assign(1, e.head);
      dist[e.head] = 0;
      for (size_t i = 0; i < q.size(); ++i) {
        const int32_t u = q[i];
        if (dist[u] >= budget) continue;
        for (int d = 0; d < 4; ++d) {
          const int32_t v = Adj(u, d);
          if (v >= 0 && dist[v] < 0 && (!body_[v] || v == queen_at_)) dist[v] = dist[u] + 1, q.push_back(v);
        }
      }
      for (int dy = -3; dy <= 3; ++dy)
        for (int dx = -3; dx <= 3; ++dx) {
          const int32_t t = mem_.Tile(mem_.X(e.head) + dx, mem_.Y(e.head) + dy);
          if (t == e.head || dist[t] < 0) continue;
          // heads around t (not the two in the clash): theirs and all
          int mine = 0, all = 0;
          for (const E& f : es) {
            if (f.id == e.id || f.head < 0) continue;
            const int ddx = std::abs(Wrap(spawn_.width, mem_.X(f.head) - mem_.X(t))), ddy = std::abs(Wrap(spawn_.height, mem_.Y(f.head) - mem_.Y(t)));
            if (ddx + ddy > kShareRadius) continue;
            ++all;
            if (f.team == spawn_.team) ++mine;
          }
          if (hunt_[t].empty()) hunt_touched_.push_back(t);
          hunt_[t].push_back(Hunter{len, (all - mine + 0.5) / (all + 1.0), e.head});   // share: the enemy's side
        }
    }
  }
  static int Wrap(int n, int d) { d %= n; if (d > n / 2) d -= n; if (d < -(n / 2)) d += n; return d; }
  // Our queen's death decides the match, and an enemy head that sees her runs onto her. A worker
  // that can reach such a head (free steps, then paid ones, up to its length less 2) trades itself
  // for it: a head-to-head kills both, and a dragon is worth less than the queen it saves.
  std::vector<int> Intercept(int32_t head, const State& now) {
    if (queen_at_ < 0 || round_ - queen_round_ > 1) return {};
    const int budget = std::min(kLungeSteps, (len_ + 3) / 4 + std::max(0, len_ - 2));
    std::vector<int32_t> dist(n_, -1);
    std::vector<int> from_dir(n_, -1);
    std::vector<int32_t> parent(n_, -1);
    std::vector<int32_t> q{head};
    dist[head] = 0;
    for (size_t i = 0; i < q.size(); ++i) {
      const int32_t u = q[i];
      if (dist[u] >= budget) continue;
      for (int d = 0; d < 4; ++d) {
        const int32_t v = Adj(u, d);
        if (v < 0 || dist[v] >= 0 || now.InBody(v)) continue;
        const bool target = std::any_of(hunt_[queen_at_].begin(), hunt_[queen_at_].end(), [&](const Hunter& h) { return h.from == v; }) ||
                            (v == hunter_heard_ && hunter_round_ == round_ && !(in_view_[v] && !body_[v]));
        if (body_[v] && !target) continue;
        dist[v] = dist[u] + 1, from_dir[v] = d, parent[v] = u, q.push_back(v);
        if (target) {
          std::vector<int> path;
          for (int32_t t = v; t != head; t = parent[t]) path.push_back(from_dir[t]);
          std::reverse(path.begin(), path.end());
          return path;
        }
      }
    }
    return {};
  }
  // does some enemy that can reach t gain by a head-to-head with a dragon of length L there?
  bool Hunted(int32_t t, int L) const {
    for (const Hunter& h : hunt_[t]) {
      const double remains = (h.len + 1) / 2 + (L + 1) / 2;
      if (L - h.len + remains * (2 * h.share - 1) > 0) return true;
    }
    return false;
  }

  // The pearl expected on t at `round` (0..1), as far as we know: a pearl seen there, or a
  // bed whose next pearl round (the round seen + its countdown) has come.
  double PearlAt(int32_t t, int round, const State* s) const {
    if (s && std::find(s->eaten.begin(), s->eaten.end(), t) != s->eaten.end()) return 0;
    const TileMemory& m = mem_.at(t);
    if (m.seen_round < 0) return 0;
    if (m.pearl) return 1;
    if (m.countdown < 0) return 0;
    return round >= m.seen_round + std::max(m.countdown, 1) ? 1 : 0;
  }

  // never-seen tiles in each tile's 7x7 view (sliding sums on the torus)
  void CountUnseen() {
    const int W = spawn_.width, H = spawn_.height;
    unseen_total_ = 0;
    for (int32_t t = 0; t < n_; ++t) unseen_total_ += unseen_[t] = mem_.at(t).seen_round < 0;
    for (int y = 0; y < H; ++y) {
      int sum = 0;
      for (int dx = -3; dx <= 3; ++dx) sum += unseen_[y * W + (dx + W) % W];
      for (int x = 0; x < W; ++x) {
        row_[y * W + x] = sum;
        sum += unseen_[y * W + (x + 4) % W] - unseen_[y * W + (x - 3 + W) % W];
      }
    }
    for (int x = 0; x < W; ++x) {
      int sum = 0;
      for (int dy = -3; dy <= 3; ++dy) sum += row_[((dy + H) % H) * W + x];
      for (int y = 0; y < H; ++y) {
        view_[y * W + x] = sum;
        sum += row_[((y + 4) % H) * W + x] - row_[((y - 3 + H) % H) * W + x];
      }
    }
  }

  // Pearls expected from the tiles a step brings into view: the row (or column) of the new
  // 7x7 view on the side it moved to, at the bed density seen so far, eaten a round or two later.
  double Reveal(int32_t t, int dir) const {
    const int x = mem_.X(t), y = mem_.Y(t);
    int count = 0;
    for (int k = -3; k <= 3; ++k) {
      const int32_t u = dir == 0 ? mem_.Tile(x + k, y - 3) : dir == 2 ? mem_.Tile(x + k, y + 3)
                      : dir == 1 ? mem_.Tile(x + 3, y + k) : mem_.Tile(x - 3, y + k);
      count += unseen_[u];
    }
    return density_ * count * kGamma * kGamma;
  }

  bool Passable(int32_t t) const { return t >= 0 && !wall_[t]; }

  // Breadth-first distances over known passable tiles from `from` (one source or many).
  void Distances(const std::vector<int32_t>& from, std::vector<int32_t>& dist) const {
    std::fill(dist.begin(), dist.end(), -1);
    std::deque<int32_t> q;
    for (int32_t f : from) dist[f] = 0, q.push_back(f);
    for (; !q.empty(); q.pop_front())
      for (int d = 0; d < 4; ++d) {
        const int32_t v = Adj(q.front(), d);
        if (Passable(v) && dist[v] < 0) dist[v] = dist[q.front()] + 1, q.push_back(v);
      }
  }

  // When could anyone else be on each tile (in steps)? Heads in view: from where they are.
  // Teammates heard of over sonar (not in view): from where they were, `age` rounds ago,
  // so they may have come age * speed steps closer: a Voronoi over everyone we know of, which
  // is what makes the team fan out instead of chasing the same targets.
  void OtherArrival(int speed) {
    std::fill(dist_other_.begin(), dist_other_.end(), -1);
    std::vector<std::pair<int, int32_t>> init;
    for (int32_t h : other_heads_) init.push_back({0, h});
    for (size_t id = 0; id < mates_.size(); ++id) {
      const Mate& m = mates_[id];
      if (m.tile < 0 || static_cast<int>(id) == spawn_.id) continue;
      if (std::find(seen_ids_.begin(), seen_ids_.end(), static_cast<int>(id)) != seen_ids_.end()) continue;
      const int age = round_ - m.round;
      if (age > kMateAge) continue;
      init.push_back({-age * speed, m.tile});
    }
    std::sort(init.begin(), init.end());
    std::vector<int> best(n_, std::numeric_limits<int>::max());
    std::priority_queue<std::pair<int, int32_t>, std::vector<std::pair<int, int32_t>>, std::greater<>> pq;
    for (auto& [d0, t] : init)
      if (d0 < best[t]) best[t] = d0, pq.push({d0, t});
    while (!pq.empty()) {
      auto [d, u] = pq.top();
      pq.pop();
      if (d > best[u]) continue;
      for (int k = 0; k < 4; ++k) {
        const int32_t v = Adj(u, k);
        if (Passable(v) && d + 1 < best[v]) best[v] = d + 1, pq.push({d + 1, v});
      }
    }
    for (int32_t t = 0; t < n_; ++t)
      if (best[t] != std::numeric_limits<int>::max()) dist_other_[t] = std::max(0, best[t]);
  }

  // The value field: field_[x] = max over targets s of value(s) * kGamma^(rounds from x to s).
  // Targets: pearls and beds (expected at the round we'd arrive), tiles whose view reveals
  // unseen ground, and tiles next to a portal whose far end we haven't found (a whole new
  // view, at the share of the board still unseen). Only targets we reach first among the
  // dragons in view count.
  // Costs are whole steps: a target of value v starts at level round(-ln v / step cost), and a
  // bucket queue spreads levels one step at a time (linear in the board).
  void BuildField(const State& now) {
    root_head_ = now.head();
    Distances({now.head()}, dist_me_);
    const int speed = std::max(1, (len_ + 3) / 4);
    OtherArrival(speed);
    const double step_cost = -std::log(kGamma) / speed;   // per step, in -ln value
    const double unseen_share = static_cast<double>(unseen_total_) / n_;
    // An unpaired portal (its far end never seen) may lead to anything we know of but can't
    // reach: the pearls seen beyond our reach and the never-seen tiles (at the bed density
    // seen). With no way to tell the portals apart, each gets an even share.
    double beyond = density_ * unseen_total_;
    int unpaired = 0;
    for (int32_t t = 0; t < n_; ++t) {
      if (dist_me_[t] < 0 && mem_.at(t).seen_round >= 0) beyond += PearlAt(t, round_, nullptr);
      if (dist_me_[t] >= 0)
        for (int d = 0; d < 4; ++d) unpaired += Adj(t, d) == ex2::kUnknown;
    }
    const double portal = unpaired ? kGamma * kGamma * beyond / unpaired : 0;
    (void)unseen_share;
    constexpr int kLevels = 1024;
    if (buckets_.size() != kLevels + 1) buckets_.assign(kLevels + 1, {});
    for (auto& b : buckets_) b.clear();
    std::fill(level_.begin(), level_.end(), kLevels + 1);
    for (int32_t s = 0; s < n_; ++s) {
      if (dist_me_[s] < 0 || (dist_other_[s] >= 0 && dist_other_[s] < dist_me_[s])) continue;
      if (!IsQueen() && zone_[s]) continue;   // nothing in the queen's territory draws a worker
      if (IsQueen() && home_ >= 0 && !zone_[now.head()] && s != home_) continue;   // a queen away from home goes home
      double v = std::max(0.0, eat_value_ * PearlAt(s, round_ + dist_me_[s] / speed, nullptr)) + density_ * view_[s] * kGamma * kGamma;
      for (int d = 0; d < 4; ++d)
        if (Adj(s, d) == ex2::kUnknown) v = std::max(v, portal);
      if (IsQueen() && s == home_ && !zone_[now.head()]) v = kHomeValue;
      if (v <= 0) continue;
      const int lv = std::max(0, static_cast<int>(std::lround((std::log(kMaxValue) - std::log(v)) / step_cost)));
      if (lv > kLevels) continue;
      level_[s] = lv;
      buckets_[lv].push_back(s);
    }
    for (int lv = 0; lv < kLevels; ++lv)
      for (size_t i = 0; i < buckets_[lv].size(); ++i) {
        const int32_t u = buckets_[lv][i];
        if (level_[u] != lv) continue;
        for (int d = 0; d < 4; ++d) {
          const int32_t v = Adj(u, d);
          if (!Passable(v) || level_[v] <= lv + 1) continue;
          level_[v] = lv + 1;
          buckets_[lv + 1].push_back(v);
        }
      }
    for (int32_t t = 0; t < n_; ++t)
      field_[t] = level_[t] > kLevels ? 0 : kMaxValue * std::exp(-level_[t] * step_cost);
  }

  // One step of a state toward `dir`, by the rules; false if it would die (or we can't tell).
  // In the first turn only tiles in view now are entered: their pearls and bodies are exact.
  bool Step(const State& s, int dir, State& out) const {
    const int32_t t = Adj(s.head(), dir);
    if (!Passable(t) || s.InBody(t)) return false;   // a body (ours, tail included) or a wall
    const bool first_turn = s.round == round_;
    // this turn, only tiles in view (their bodies and pearls are exact); a portal's far side out
    // of view is crossed only after a sonar probe (see Turn), never on memory alone
    const bool blind = first_turn && !in_view_[t];
    if (blind) return false;
    out = s;
    const double p = PearlAt(t, s.round, &s);
    out.body.insert(out.body.begin(), t);
    if (p > 0) {   // a (likely) pearl keeps the tail in place: the cautious reading for the body
      out.eaten.push_back(t);
      ++out.len;
    } else if (out.unknown > 0) {
      --out.unknown;
    } else {
      out.body.pop_back();
    }
    const double discount = std::pow(kGamma, s.round - round_);
    // a settled queen outside her territory earns nothing on the way: only the way home counts
    if (!(IsQueen() && home_ >= 0 && !zone_[root_head_])) out.score += discount * (eat_value_ * p + Reveal(t, dir));
    if (!IsQueen() && zone_[t]) out.score -= kInTerritory;   // a worker inside the queen's territory walks out
    --out.left;
    ++out.in_turn;
    return true;
  }

  // The turn ends: the next turn starts with the free steps of the length then.
  void EndTurn(State& s) const {
    // another head may lunge here: the dragon's worth (the queen: never)
    if (s.round == round_ && head_near_[s.head()]) s.score -= IsQueen() ? 1e9 : s.len;
    else if (s.round == round_ && IsQueen() && !hunt_[s.head()].empty()) s.score -= 1e9;   // her death decides the match: any hunter
    else if (s.round == round_ && !IsQueen() && Hunted(s.head(), s.len)) s.score -= s.len;
    if (s.round == round_ && IsQueen() && mouth_[s.head()]) s.score -= 1e9;
    ++s.round;
    s.left = (s.len + 3) / 4;
    s.in_turn = 0;
  }

  // Survival: can this body keep moving for `need` more steps (other bodies as walls)?
  // A depth-first search done in place: the body is a ring buffer, occ_ counts our segments
  // per tile and ate_ marks pearls eaten on the way, each step undone on the way back. Steps
  // with more free neighbours are tried first, so a way out is usually found at once.
  // `next_round`: the state ends a turn; before our next one every other dragon in view may
  // move its head a tile, so a tile next to another head can't be counted on for the first step.
  // Lookahead: how many steps (up to `need`) this state can be seen to survive.
  int Lasts(const State& s, int need = -1, bool next_round = true) {
    if (need < 0) need = Need(s.len, false);
    const int L = static_cast<int>(s.body.size());
    for (int i = 0; i < L; ++i) ring_[(i) & kRingMask] = s.body[i], ++occ_[s.body[i]];
    rhead_ = 0, rlen_ = L, runk_ = s.unknown;
    for (int32_t t : s.eaten) ate_[t] = 1;
    budget_ = IsQueen() ? kQueenBudget : kSurviveBudget;
    const int got = Go(need, s.round, next_round);
    for (int i = 0; i < L; ++i) --occ_[s.body[i]];
    for (int32_t t : s.eaten) ate_[t] = 0;
    return got;
  }
  // The race lookahead: steps over tiles this dragon reaches before any other head in view could.
  int Races(const State& s, int need) {
    race_ = true, race_need_ = need, race_speed_ = std::max(1, (s.len + 3) / 4);
    const int got = Lasts(s, need);
    race_ = false;
    return got;
  }
  // contest_[t]: the earliest round after this turn another head in view could be on t (its
  // distance over its own speed, from the length we see of it); kNever when none can.
  void Contest(const rl::Observation& o) {
    std::fill(contest_.begin(), contest_.end(), kNever);
    std::unordered_map<int32_t, int> seen_len;
    std::unordered_map<int32_t, int32_t> head_of;
    for (const rl::Segment& sg : o.segments) {
      if (sg.id == spawn_.id) continue;
      ++seen_len[sg.id];
      if (sg.head) head_of[sg.id] = mem_.Tile(sg.x, sg.y);
    }
    std::vector<int32_t> dist(n_, -1);
    for (const auto& [id, h] : head_of) {
      const int len = seen_len[id] + 4;   // it may run on out of view
      const int speed = std::max(1, (len + 3) / 4);
      Distances({h}, dist);
      for (int32_t t = 0; t < n_; ++t)
        if (dist[t] >= 0) contest_[t] = std::min(contest_[t], (dist[t] + speed - 1) / speed);
    }
  }

  bool Safe(const State& s, bool queen) { return Lasts(s, Need(s.len, queen)) >= Need(s.len, queen); }
  // Steps the lookahead must find on known ground: unseen tiles count as blocked, so a corridor
  // whose far end nobody has seen (or reported) can't supply them; open ground, a loop, or a
  // corridor with a known way out can. The queen asks for twice as many.
  static int Need(int len, bool queen) { return std::max(len + 1, queen ? kQueenSteps : kSurviveSteps); }
  // Inside her walled territory no worker comes in: a short loop is all the queen needs there.
  static int ZoneNeed(int len) { return std::max(len + 2, kZoneSteps); }
  int QueenNeed(int len) const { return walled_.empty() ? Need(len, true) : ZoneNeed(len); }
  int FreeAround(int32_t t) const {
    int k = 0;
    for (int d = 0; d < 4; ++d)
      if (const int32_t u = Adj(t, d); Passable(u) && !occ_[u]) ++k;
    return k;
  }
  // the longest run of steps found (up to need; past the budget, need is assumed)
  int Go(int need, int round, bool next_round) {
    if (need <= 0) return 0;
    // out of budget: a worker assumes a way out; the queen doesn't (an unexplored maze branch isn't one)
    if (--budget_ < 0) return IsQueen() ? 0 : need;
    const int32_t head = ring_[rhead_];
    // the race: the k-th step lands in round k / speed after this turn; the tile must be one no
    // other head (in view) can reach by then
    const int step = race_need_ - need + 1, when = (step + race_speed_ - 1) / race_speed_;
    int32_t to[4];
    int deg[4], n = 0;
    for (int d = 0; d < 4; ++d) {
      const int32_t t = Adj(head, d);
      if (!Passable(t) || occ_[t] || (next_round && head_near_[t])) continue;
      if (race_ && when >= contest_[t]) continue;
      to[n] = t, deg[n] = FreeAround(t), ++n;
    }
    for (int i = 1; i < n; ++i)   // most free neighbours first
      for (int j = i; j > 0 && deg[j] > deg[j - 1]; --j) std::swap(deg[j], deg[j - 1]), std::swap(to[j], to[j - 1]);
    int best = 0;
    for (int i = 0; i < n; ++i) {
      const int32_t t = to[i];
      const bool eat = !ate_[t] && PearlAt(t, round, nullptr) > 0;
      rhead_ = (rhead_ - 1) & kRingMask;
      ring_[rhead_] = t;
      ++occ_[t], ++rlen_;
      int32_t popped = -1;
      bool from_unknown = false;
      if (eat) ate_[t] = 1;
      else if (runk_ > 0) --runk_, from_unknown = true;
      else popped = ring_[(rhead_ + rlen_ - 1) & kRingMask], --occ_[popped], --rlen_;
      const int got = 1 + Go(need - 1, round, false);
      if (eat) ate_[t] = 0;
      else if (from_unknown) ++runk_;
      else ++occ_[popped], ++rlen_;
      --occ_[t], --rlen_;
      rhead_ = (rhead_ + 1) & kRingMask;
      best = std::max(best, got);
      if (best >= need) break;
    }
    return best;
  }

  // Split in half: the tail half becomes a new dragon, its head at our tail. Both must survive.
  bool SplitSafe(const State& now) {
    const int child_len = len_ / 2;
    State parent = now, child = now;
    parent.body.resize(len_ - child_len);
    parent.len = len_ - child_len;
    child.body.assign(now.body.rbegin(), now.body.rbegin() + child_len);
    child.len = child_len;
    for (int32_t t : child.body) wall_[t] = 1;
    // the parent only gets shorter, so it needs the ordinary L + 1 steps, the queen included
    const bool parent_ok = Lasts(parent, parent.len + 1) >= parent.len + 1;
    for (int32_t t : child.body) wall_[t] = 0;
    for (int32_t t : parent.body) wall_[t] = 1;
    bool child_ok = false;
    for (int d = 0; d < 4 && !child_ok; ++d)   // the child's first step must be in view
      if (const int32_t t = Adj(child.head(), d); Passable(t) && in_view_[t] && !child.InBody(t)) child_ok = true;
    child_ok = child_ok && Safe(child, false);
    for (int32_t t : parent.body) wall_[t] = 0;
    return parent_ok && child_ok;
  }

  // A queen longer than kQueenMaxLen sheds length: after the plan's steps she keeps stepping
  // onto pearl-free tiles in view; every step past the first ceil(L/4) of the move costs a
  // segment (the sprint rule). Each step must leave her a state that lasts her lookahead.
  void Shrink(const State& now, std::vector<int>& steps) {
    State cur = now;
    for (size_t i = 0; i < steps.size(); ++i) {   // replay the plan exactly
      const int32_t t = Adj(cur.head(), steps[i]);
      cur.body.insert(cur.body.begin(), t);
      if (PearlAt(t, round_, &cur) > 0) cur.eaten.push_back(t), ++cur.len;
      else if (cur.unknown > 0) --cur.unknown;
      else cur.body.pop_back();
    }
    const int free_steps = (len_ + 3) / 4;
    while (cur.len > kQueenMaxLen && cur.len > 2 && static_cast<int>(steps.size()) < 2 * len_) {
      const bool paid = static_cast<int>(steps.size()) >= free_steps;
      int best_d = -1, best_lasts = -1;
      State best_state;
      for (int d = 0; d < 4; ++d) {
        const int32_t t = Adj(cur.head(), d);
        if (!Passable(t) || !in_view_[t] || cur.InBody(t) || PearlAt(t, round_, &cur) > 0 || head_near_[t] || mouth_[t]) continue;
        State next = cur;
        next.body.insert(next.body.begin(), t);
        for (int pop = 0; pop < (paid ? 2 : 1); ++pop) {
          if (next.unknown > 0) --next.unknown;
          else next.body.pop_back();
        }
        if (paid) --next.len;
        const int need = QueenNeed(next.len), lasts = Lasts(next, need);
        if (lasts >= need && lasts > best_lasts) best_lasts = lasts, best_d = d, best_state = next;
      }
      if (best_d < 0) break;
      steps.push_back(best_d);
      cur = std::move(best_state);
    }
  }

  bool BlockingQueen(const rl::Observation& o, const State& me) {
    State q;
    for (const rl::Segment& sg : o.segments)
      if (sg.id <= 1 && sg.team == spawn_.team) q.body.push_back(mem_.Tile(sg.x, sg.y));
    if (q.body.empty() || !in_view_[q.body.front()]) return false;
    q.len = static_cast<int>(q.body.size());
    q.round = round_;
    const int need = q.len + kCorneredSteps;
    for (int32_t t : q.body) wall_[t] -= 1;   // her own body is hers in the lookahead, not a wall
    for (int32_t t : me.body) wall_[t] += 1;  // ours is a wall to her
    bool blocking = false;
    if (kDebugTmp) std::fprintf(stderr, "BQ r%d id%d qlen%d need%d lasts%d qhead(%d,%d)\n", round_, spawn_.id, q.len, need, Lasts(q, need, false), mem_.X(q.body.front()), mem_.Y(q.body.front()));
    if (Lasts(q, need, false) < need) {
      for (int32_t t : me.body) wall_[t] -= 1;
      blocking = Lasts(q, need, false) >= need;
      for (int32_t t : me.body) wall_[t] += 1;
    }
    for (int32_t t : me.body) wall_[t] -= 1;
    for (int32_t t : q.body) wall_[t] += 1;
    return blocking;
  }

  // Escape split: the best split size n (0: none beats `moving`, the steps the best move lasts).
  // The child (our last n segments, reversed) acts later this round, so before our next move
  // its last segment's tile (our segment L - n) has cleared: the parent's lookahead walls the
  // child's body except that tile; the child's walls the parent's body. A child with no step at
  // all resigns this round (as this bot does when it can't move), freeing its tiles: then only
  // the parent counts, on a board without the child (a sacrifice split).
  int EscapeSplit(const State& now, int moving) {
    int best_n = 0, best = moving;
    // a dragon that can't last its full lookahead (cornered, in a dead end) is doomed by its own
    // length: the child that walks out of the other end of the body saves what the parent can't
    const bool cornered = !IsQueen() && moving < Need(len_, false);
    int save_n = 0;
    for (int n = 2; n <= len_ - 2; ++n) {
      State parent = now, child = now;
      parent.body.assign(now.body.begin(), now.body.end() - n);
      parent.len = len_ - n;
      child.body.assign(now.body.rbegin(), now.body.rbegin() + n);
      child.len = n;
      for (int i = 0; i + 1 < n; ++i) wall_[child.body[i]] += 1;   // all but the child's last segment
      const int p = Lasts(parent, parent.len + 1);
      for (int i = 0; i + 1 < n; ++i) wall_[child.body[i]] -= 1;
      for (int32_t t : parent.body) wall_[t] += 1;
      bool first = false;
      for (int d = 0; d < 4 && !first; ++d)
        if (const int32_t t = Adj(child.head(), d); Passable(t) && (in_view_[t] || cornered) && !child.InBody(t)) first = true;
      const int c = first && (std::min(p, n + 1) > best || cornered) ? Lasts(child, n + 1) : 0;
      if (kDebugTmp) std::fprintf(stderr, "ES r%d id%d n%d p%d first%d c%d moving%d cornered%d unk%d\n", round_, spawn_.id, n, p, (int)first, c, moving, (int)cornered, now.unknown);
      if (cornered && c >= n + 1) save_n = n;   // the biggest child that is fully safe
      for (int32_t t : parent.body) wall_[t] -= 1;
      if (std::min(p, c) > best) best = std::min(p, c), best_n = n;
      if (!first) {   // the child will resign: the parent alone, the child's tiles free
        const int alone = Lasts(parent, parent.len + 1);
        if (alone > best) best = alone, best_n = n;
      } else if (moving < 2 && p < 2 && c > best) {   // we're doomed either way: save the child
        best = c, best_n = n;
      }
    }
    return best_n > 0 ? best_n : save_n;
  }

  // The beam search. Returns the first turn's steps of the best plan that survives.
  std::vector<int> Search(const State& root) {
    plans_.clear();
    // a state costs about its length to copy and check: the width shrinks as the dragon grows
    const int width = std::clamp(kBeam * 6 / (root.len + 2), 8, kBeam);
    std::vector<State> beam{root}, next;
    for (int depth = 0; depth < kHorizon && !beam.empty(); ++depth) {
      next.clear();
      for (const State& s : beam) {
        for (int d = 0; d < 4; ++d) {
          State c;
          if (!Step(s, d, c)) continue;
          Extend(s, d, c, next);
        }
        // stop the turn here (after at least one step), then go on next turn
        if (s.in_turn > 0 && s.left > 0) {
          State c = s;
          c.left = 0;
          Close(c, next);
        }
      }
      // keep the best kBeam, one per (head, neck, round)
      std::sort(next.begin(), next.end(), [](const State& a, const State& b) { return a.est > b.est; });
      beam.clear();
      std::unordered_map<uint64_t, int> taken;
      for (State& s : next) {
        const uint64_t key = (static_cast<uint64_t>(s.head()) << 40) ^ (static_cast<uint64_t>(s.body.size() > 1 ? s.body[1] : -1) << 16) ^ static_cast<uint64_t>(s.round);
        if (taken.count(key)) continue;
        taken[key] = 1;
        beam.push_back(std::move(s));
        if (static_cast<int>(beam.size()) == width) break;
      }
    }
    // plans, best first; the first whose end state survives
    std::vector<int> order(plans_.size());
    for (size_t i = 0; i < order.size(); ++i) order[i] = static_cast<int>(i);
    std::sort(order.begin(), order.end(), [&](int a, int b) { return plans_[a].best > plans_[b].best; });
    // the best plan whose end state lasts L + 1 steps in the lookahead; if none does, the one
    // that lasts the most (resigning only when no step is legal at all)
    const int full = IsQueen() ? QueenNeed(root.len) : Need(root.len, false);
    // a plan that breaks a hard rule (the queen ending beside another head or on a portal
    // mouth: scored -1e9) is taken only if no other plan lasts at all
    int best_plan = -1, best_lasts = -1, best_rank = -1, checked = 0;
    for (int i : order) {
      Plan& p = plans_[i];
      if (p.steps.empty() || p.end.body.empty()) continue;
      const int lasts = Lasts(p.end, full);
      // the queen also needs a short escape over tiles she wins the race to
      const bool lawful = p.best > -1e8 && (!IsQueen() || Races(p.end, std::min(p.end.len + 2, kRaceSteps)) >= std::min(p.end.len + 2, kRaceSteps));
      const int rank = (lawful && lasts >= full ? 3 : lawful && lasts >= 2 ? 2 : lasts >= 2 ? 1 : 0);
      if (rank > best_rank || (rank == best_rank && lasts > best_lasts)) best_rank = rank, best_lasts = lasts, best_plan = i;
      if ((rank == 3) || ++checked >= kPlansChecked) break;
    }
    last_lasts_ = best_lasts;
    chosen_plan_ = best_plan;
    if (best_plan >= 0 && best_lasts > 0) {
      why_ = best_lasts < full ? "cornered" : plans_[best_plan].best > 0 ? "plan" : "survive";
      return plans_[best_plan].steps;
    }
    for (int i : order)   // nothing lasts a step past this turn: still better than resigning now
      if (!plans_[i].steps.empty()) {
        why_ = "doomed";
        return plans_[i].steps;
      }
    return {};
  }

  // c is s after step `dir`: record it in its plan (the first turn) and queue it.
  void Extend(const State& s, int dir, State& c, std::vector<State>& next) {
    if (s.round == round_) {   // first turn: c's plan is s's steps plus this one
      Plan p;
      if (s.plan >= 0) p.steps = plans_[s.plan].steps;
      p.steps.push_back(dir);
      c.plan = static_cast<int>(plans_.size());
      plans_.push_back(std::move(p));
    }
    if (c.left == 0) {
      Close(c, next);
      return;
    }
    Score(c);
    next.push_back(std::move(c));
  }

  // c ends a turn: if it was the first, its plan's end state is fixed now
  void Close(State& c, std::vector<State>& next) {
    const bool first = c.round == round_;
    EndTurn(c);
    if (first) plans_[c.plan].end = c;
    Score(c);
    next.push_back(std::move(c));
  }

  void Score(State& c) {
    c.est = c.score + std::pow(kGamma, c.round - round_) * field_[c.head()];
    if (c.plan >= 0) plans_[c.plan].best = std::max(plans_[c.plan].best, c.est);
  }

  rl::Spawn spawn_;
  TeamMemory mem_;
  int32_t n_;
  int round_ = 0, len_ = 0, unseen_total_ = 0;
  int berth_ = kQueenBerth;
  double density_ = 0;
  double eat_value_ = 1;
  int32_t probe_tile_ = -1;   // where we stood when we probed a portal, the direction, the round
  int probe_dir_ = 0, probe_round_ = -1;
  bool crossing_ = false;
  int last_lasts_ = 0;
  int chosen_plan_ = -1;
  int32_t root_head_ = 0;     // the head at the start of this turn's search
  int32_t distress_heard_ = -1;   // where our queen called for room from, this round
  bool race_ = false;          // the lookahead is the race (Races)
  int race_need_ = 0, race_speed_ = 1;
  std::vector<int32_t> contest_ = std::vector<int32_t>(n_, kNever);
  int32_t home_ = -1;         // the centre of our queen's territory (hers from the start; workers hear it)
  std::vector<uint8_t> zone_ = std::vector<uint8_t>(n_, 0);
  std::vector<int32_t> zone_q_;
  std::vector<int32_t> walled_;   // the queen's boundary this turn: tiles walled for being outside her territory
  std::vector<uint8_t> mouth_ = std::vector<uint8_t>(n_, 0);   // the queen's view: tiles beside a portal edge      // the plan Search picked (its index in plans_)
  int32_t queen_at_ = -1;     // our queen's head when last seen or heard of, and the round
  int queen_round_ = -1;        // the steps the chosen plan's end state lasted in the lookahead     // we stepped through a portal blind last turn   // what a pearl is worth to this dragon now
  std::vector<int32_t> trail_, other_heads_;
  struct Mate { int32_t tile = -1; int round = -1; };
  std::vector<int> relayed_ = std::vector<int>(128, -1);   // per teammate: the report round we last passed on
  std::vector<Mate> mates_;          // teammates' heads as last heard of, by dragon id
  std::vector<int> seen_ids_;        // teammates whose heads are in view this turn
  std::vector<uint8_t> wall_, head_near_;
  struct Hunter { int len; double share; int32_t from; };
  std::vector<std::vector<Hunter>> hunt_ = std::vector<std::vector<Hunter>>(n_);
  std::vector<int32_t> hunt_touched_;
  int32_t alert_ = -1, hunter_heard_ = -1;   // the hunter we call workers onto (queen); the one we heard of
  int hunter_round_ = -1;
  std::vector<uint8_t> body_ = std::vector<uint8_t>(n_, 0);
  std::vector<int32_t> unseen_, view_, row_, dist_me_, dist_other_;
  std::vector<double> field_;
  std::vector<uint8_t> in_view_;                 // in this round's 7x7 view (bodies and pearls exact)
  std::vector<int32_t> last_sent_, sent_seen_;   // per tile: the round we last sent it, and its seen round then
  std::vector<Plan> plans_;
  std::vector<int32_t> adj_ = std::vector<int32_t>(4 * n_), level_ = std::vector<int32_t>(n_);
  std::vector<std::vector<int32_t>> buckets_;
  std::vector<int32_t> ring_ = std::vector<int32_t>(kRingMask + 1);   // survival search state
  std::vector<uint8_t> occ_, ate_;
  int rhead_ = 0, rlen_ = 0, runk_ = 0, budget_ = 0;
  const char* why_ = "";
};

}  // namespace

LEAGUE_VARIANT(Explorer)
